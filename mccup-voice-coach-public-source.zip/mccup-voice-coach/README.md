# マイクラカップ チーム練習

公開版の見本6問からランダムに出題し、声で質疑応答を練習できます。チーム専用リンクでは優先20問または全156問を使えます。6項目の通し練習では、全項目の練習点を60点満点で表示します。

[ブラウザーで練習する](https://mccup-voice-practice.wp4cj22wdr.chatgpt.site/)

## ブラウザー版

- SafariまたはChromeで開き、録音時にマイクを許可してください。初回は文字起こしと採点のモデルをダウンロードします。
- 録音は端末内のWhisperで文字にし、日本語の端末内音声で質問と講評を読み上げます。採点は文章の関連度と説明の具体さをもとにした練習点です。
- チーム参加者は管理者から受け取った本人用リンクで開きます。「挑戦の記録」でチームのタイムラインが開き、名前、日時、問題、回答、講評、点数が新しい順に並びます。名前を選ぶと1人分に絞り込めます。チームの記録は送信前にAES-GCMで暗号化します。
- 公開ソースにはチームの質問集、参加者の名前、招待リンク、回答、録音、記録を含めていません。

`npm run build` で Sites 用の Worker を生成します。同期にはR2バインディング `BUCKET` と、運用者が環境変数として設定する `TEAM_HASHES`・`TEAM_PROFILES` が必要です。公開モードの練習は同期設定なしでも動きます。端末内モデルは Transformers.js 3.8.1、Whisper Tiny、日本語対応の Multilingual E5 Small です。

## Mac版

Apple Silicon、macOS 26、Apple Intelligenceが必要です。Mac版用のチーム質問集を別途用意し、ソースから作るにはXcode Command Line Toolsで `zsh build.sh` を実行します。別のMacでWhisperを準備する場合は、Apple Silicon用Python 3.10以降で一度 `zsh setup-whisper.sh` を実行してください。Mac版の記録はそのMacに保存され、チームの自動同期はブラウザー版で利用できます。
