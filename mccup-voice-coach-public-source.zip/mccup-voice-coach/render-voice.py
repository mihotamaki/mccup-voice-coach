"""Generate short MP3 clips locally using Open JTalk and HTS Voice Mei."""
import base64
import json
import subprocess
import sys

import numpy as np
import pyopenjtalk

READINGS = {
    "尾鷲": "おわせ", "須賀利": "すがり", "九鬼": "くき", "天満荘": "てんまそう",
    "β": "ベータ", "AI": "エーアイ", "MakeCode": "メイクコード",
}

def render(text):
    for term, reading in READINGS.items():
        text = text.replace(term, reading)
    samples, rate = pyopenjtalk.tts(text)
    voiced = np.flatnonzero(np.abs(samples) > 300)
    if voiced.size:
        samples = samples[max(0, voiced[0] - rate // 20):voiced[-1] + rate // 10]
    pcm = np.clip(samples, -32768, 32767).astype("<i2")
    result = subprocess.run([
        "ffmpeg", "-hide_banner", "-loglevel", "error", "-f", "s16le",
        "-ar", str(rate), "-ac", "1", "-i", "pipe:0", "-ar", "16000",
        "-codec:a", "libmp3lame", "-b:a", "16k", "-f", "mp3", "pipe:1",
    ], input=pcm.tobytes(), stdout=subprocess.PIPE, check=True)
    return base64.b64encode(result.stdout).decode("ascii")

json.dump({name: render(text) for name, text in json.load(sys.stdin)}, sys.stdout)
