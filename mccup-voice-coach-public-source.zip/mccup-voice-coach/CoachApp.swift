import AVFoundation
import SwiftUI

@main
struct CoachApp: App {
    var body: some Scene {
        Window("マイクラカップ チーム練習", id: "main") { CoachView() }
            .defaultSize(width: 760, height: 650)
            .windowResizability(.contentMinSize)
    }
}

@MainActor
final class Coach: NSObject, ObservableObject, AVSpeechSynthesizerDelegate {
    @Published var priorityOnly = true
    @Published var full = false
    @Published var answer = ""
    @Published var notice = ""
    @Published var showReset = false
    @Published var showName = false
    @Published var nameDraft = ""
    @Published var memberID = 0
    @Published var showingHistory = false
    @Published private(set) var history = History()
    private var practiceID = UUID()
    private var pending: (result: Result, attempt: Attempt)?
    @Published private(set) var deck: [Question] = []
    @Published private(set) var results: [Result] = []
    @Published private(set) var phase: Phase = .ready
    @Published private(set) var speaking = false
    @Published private(set) var seconds = 0

    enum Phase: Equatable {
        case ready, microphone, recording, transcription, grading
        var busy: Bool { self != .ready }
    }

    private let bank: [Question]
    private let speaker = AVSpeechSynthesizer()
    private let recorder = Recorder()
    private var speech: AVSpeechUtterance?
    private var timer: Task<Void, Never>?

    override init() {
        do {
            guard let url = Bundle.main.url(forResource: "questions", withExtension: "json") else {
                throw PracticeError.questions
            }
            bank = try QuestionBank.load(url)
        } catch { bank = [] }
        super.init()
        speaker.delegate = self
        if bank.isEmpty { notice = PracticeError.questions.localizedDescription }
    }

    var canStart: Bool { !bank.isEmpty }
    var current: Question? { deck.indices.contains(results.count) ? deck[results.count] : nil }
    var finished: Bool { !deck.isEmpty && current == nil }
    var completeScore: Int? {
        guard results.count == 6, results.allSatisfy({ $0.grade != nil }) else { return nil }
        return results.compactMap { $0.grade?.score }.reduce(0, +)
    }
    var cleanAnswer: String { answer.trimmingCharacters(in: .whitespacesAndNewlines) }
    var member: Member { history.members[memberID] }
    var mayChangeMember: Bool { deck.isEmpty || finished }
    var waitingToSave: Bool { pending != nil }

    func chooseMember(_ id: Int) {
        guard mayChangeMember else { return }
        reset()
        memberID = id
    }

    func editName() {
        nameDraft = member.name
        showName = true
    }

    func saveName() {
        objectWillChange.send()
        do {
            try history.rename(memberID, to: nameDraft)
            notice = ""
        } catch {
            notice = history.error ?? "名前を入力してください。"
        }
    }

    func start() {
        practiceID = UUID()
        showingHistory = false
        results = []
        answer = ""
        notice = ""
        deck = QuestionBank.draw(from: priorityOnly ? bank.filter(\.priority) : bank, full: full)
        if deck.isEmpty { notice = PracticeError.questions.localizedDescription }
        readQuestion()
    }

    func reset() {
        stopSpeaking()
        pending = nil
        deck = []
        results = []
        answer = ""
        notice = ""
    }

    func readQuestion() {
        if let current { speak(current.text) }
    }

    func stopSpeaking() {
        speech = nil
        speaker.stopSpeaking(at: .immediate)
        speaking = false
    }

    private func speak(_ text: String) {
        stopSpeaking()
        let utterance = AVSpeechUtterance(string: text)
        utterance.voice = AVSpeechSynthesisVoice(language: "ja-JP")
        utterance.rate = 0.46
        speech = utterance
        speaking = true
        speaker.speak(utterance)
    }

    nonisolated func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didFinish utterance: AVSpeechUtterance) {
        finishSpeech(ObjectIdentifier(utterance))
    }

    nonisolated func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didCancel utterance: AVSpeechUtterance) {
        finishSpeech(ObjectIdentifier(utterance))
    }

    private nonisolated func finishSpeech(_ identifier: ObjectIdentifier) {
        Task { @MainActor in
            if let speech, ObjectIdentifier(speech) == identifier {
                self.speech = nil
                speaking = false
            }
        }
    }

    func beginRecording() {
        guard phase == .ready, !speaking else { return }
        notice = ""
        phase = .microphone
        Task {
            do {
                try await recorder.start()
                phase = .recording
                seconds = 0
                timer = Task {
                    for second in 1...90 {
                        do { try await Task.sleep(for: .seconds(1)) } catch { return }
                        seconds = second
                    }
                    endRecording()
                }
            } catch {
                notice = error.localizedDescription
                phase = .ready
            }
        }
    }

    func endRecording() {
        guard phase == .recording else { return }
        timer?.cancel()
        timer = nil
        let (pcm, rate) = recorder.stop()
        phase = .transcription
        Task {
            defer { phase = .ready }
            guard let script = Bundle.main.url(forResource: "transcribe", withExtension: "py") else {
                notice = PracticeError.transcription.localizedDescription
                return
            }
            do {
                let text = try await Transcriber.read(pcm, rate: rate, script: script)
                if text.isEmpty { notice = "声を聞き取れませんでした。もう一度録るか、回答を入力してください。" }
                else { answer = text }
            } catch { notice = error.localizedDescription }
        }
    }

    func grade() {
        guard phase == .ready, let current, !cleanAnswer.isEmpty else { return }
        if pending != nil { savePending(); return }
        let submitted = cleanAnswer
        guard submitted.count <= 1200 else {
            notice = "回答を1200文字以内にしてから採点してください。"
            return
        }
        stopSpeaking()
        notice = ""
        phase = .grading
        Task {
            defer { phase = .ready }
            do {
                let grade = try await Grader.grade(submitted, for: current)
                let result = Result(question: current, grade: grade)
                let attempt = Attempt(id: UUID(), session: practiceID, at: Date(), question: current.text,
                                      answer: submitted, criterion: result.criterion, score: grade.score,
                                      good: grade.good, evidence: grade.evidence, next: grade.next)
                pending = (result, attempt)
                savePending()
            } catch let error as PracticeError { notice = error.localizedDescription }
            catch { notice = PracticeError.grade.localizedDescription }
        }
    }

    private func savePending() {
        guard let pending else { return }
        do {
            objectWillChange.send()
            try history.add(pending.attempt, member: memberID)
            self.pending = nil
            advance(pending.result)
        } catch {
            notice = history.error ?? "結果を保存できませんでした。"
        }
    }

    func skip() {
        guard phase == .ready, let current else { return }
        pending = nil
        advance(Result(question: current, grade: nil))
    }

    private func advance(_ result: Result) {
        answer = ""
        notice = ""
        results.append(result)
        if finished { readResults() }
        else { readQuestion() }
    }

    func readResults() {
        var lines = ["練習の結果です。"] + results.map(\.spokenScore)
        if let completeScore { lines.append("合計は、60点満点で\(completeScore)点です。") }
        else if deck.count == 6 { lines.append("未評価の項目があるため、合計は出ていません。") }

        let grades = results.compactMap(\.grade)
        if let good = grades.sorted(by: { $0.score > $1.score }).first(where: { !$0.good.isEmpty })?.good {
            lines.append("良かった点。\(good)")
        }
        if let next = grades.min(by: { $0.score < $1.score })?.next {
            lines.append(next)
        }
        speak(lines.joined(separator: " "))
    }
}

struct CoachView: View {
    @StateObject private var coach = Coach()

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                header
                if coach.mayChangeMember { memberBar }
                if coach.showingHistory && coach.mayChangeMember { historyPanel }
                else if let question = coach.current { questionPanel(question) }
                else if coach.finished { resultsPanel }
                else { setupPanel }
                if !coach.notice.isEmpty {
                    Label(coach.notice, systemImage: "info.circle")
                        .foregroundStyle(.orange)
                }
            }
            .padding(34)
            .frame(maxWidth: 820, alignment: .leading)
            .frame(maxWidth: .infinity)
        }
        .frame(minWidth: 560, minHeight: 480)
        .alert("いまの練習を終えますか？", isPresented: $coach.showReset) {
            Button("続ける", role: .cancel) {}
            Button("練習を終える", role: .destructive) { coach.reset() }
        } message: {
            Text("採点済みの回答は記録タブで見返せます。")
        }
        .alert("表示する名前", isPresented: $coach.showName) {
            TextField("名前", text: $coach.nameDraft)
            Button("キャンセル", role: .cancel) {}
            Button("保存", action: coach.saveName)
        }
    }

    private var memberBar: some View {
        VStack(alignment: .leading, spacing: 12) {
            Picker("メンバー", selection: Binding(get: { coach.memberID }, set: coach.chooseMember)) {
                ForEach(coach.history.members) { member in
                    Text(member.name).tag(member.id)
                }
            }
            .pickerStyle(.segmented)
            HStack {
                Picker("画面", selection: $coach.showingHistory) {
                    Text("練習").tag(false)
                    Text("挑戦の記録").tag(true)
                }.pickerStyle(.segmented)
                Spacer(minLength: 12)
                Button("名前を変える", action: coach.editName)
            }
        }
    }

    private var historyPanel: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("\(coach.member.name) の挑戦の記録").font(.title2.bold())
            Text("練習 \(Set(coach.member.attempts.map(\.session)).count) 回　・　回答した問題 \(coach.member.attempts.count) 問")
                .font(.headline)
            if let error = coach.history.error { Text(error).foregroundStyle(.orange) }
            if coach.member.attempts.isEmpty {
                Text("ここに質問・回答・講評・点数が並びます。").foregroundStyle(.secondary)
            }
            ForEach(coach.member.attempts.reversed()) { item in
                VStack(alignment: .leading, spacing: 8) {
                    HStack {
                        Text(item.at, format: .dateTime.month().day().hour().minute()).foregroundStyle(.secondary)
                        Spacer()
                        Text("\(item.criterion)　\(item.score) / 10").font(.headline)
                    }
                    Text("問題").font(.caption.bold()).foregroundStyle(.secondary)
                    Text(item.question).font(.headline)
                    Text("回答").font(.caption.bold()).foregroundStyle(.secondary)
                    Text(item.answer).textSelection(.enabled)
                    Text("講評").font(.caption.bold()).foregroundStyle(.secondary)
                    if !item.good.isEmpty { Label(item.good, systemImage: "hand.thumbsup") }
                    Label(item.next, systemImage: "arrow.turn.down.right")
                }
                .padding(14)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(.background, in: RoundedRectangle(cornerRadius: 10))
            }
        }
        .padding(23)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 16))
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 8) {
            Label("チーム練習  /  マイクラカップ", systemImage: "waveform")
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(.teal)
            Text("声で 質疑応答の練習")
                .font(.system(size: 34, weight: .bold, design: .rounded))
            Text("質問を聞いて、自分のことばで答えてみよう。")
                .foregroundStyle(.secondary)
        }
        .accessibilityElement(children: .combine)
    }

    private var setupPanel: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("練習を選ぶ").font(.title2.bold())
            Picker("練習モード", selection: $coach.full) {
                Text("1問だけ").tag(false)
                Text("6項目の通し練習").tag(true)
            }.pickerStyle(.segmented)
            Picker("質問の範囲", selection: $coach.priorityOnly) {
                Text("★ 優先20問").tag(true)
                Text("全156問").tag(false)
            }.pickerStyle(.segmented)
            Text(coach.full ? "6つの審査項目から、1問ずつ順番を混ぜて読み上げます。" :
                    "選んだ範囲から、ランダムに1問読み上げます。")
                .foregroundStyle(.secondary)
            Button { coach.start() } label: {
                Label("練習をはじめる", systemImage: "play.fill")
            }
            .buttonStyle(.borderedProminent)
            .controlSize(.large)
            .disabled(!coach.canStart)
            Label("音声はこのMacの中で文字にします。回答と点数は、このMacに暗号化して保存します。",
                  systemImage: "lock")
                .font(.footnote)
                .foregroundStyle(.secondary)
        }
        .padding(23)
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 16))
    }

    private func questionPanel(_ question: Question) -> some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                Text("\(coach.member.name)　·　\(coach.results.count + 1) / \(coach.deck.count) 問")
                    .font(.subheadline.bold())
                    .monospacedDigit()
                Spacer()
                if coach.speaking {
                    Button("読み上げを止める", systemImage: "stop.circle", action: coach.stopSpeaking)
                } else {
                    Button("もう一度聞く", systemImage: "speaker.wave.2", action: coach.readQuestion)
                        .disabled(coach.phase.busy)
                }
            }
            Text(question.text)
                .font(.title2.weight(.semibold))
                .fixedSize(horizontal: false, vertical: true)
                .padding(.bottom, 4)
            if coach.phase == .recording {
                Button("話し終わった（\(coach.seconds)秒）", systemImage: "stop.fill", action: coach.endRecording)
                    .buttonStyle(.borderedProminent)
                    .tint(.red)
                    .controlSize(.large)
            } else if coach.phase == .ready {
                Button(coach.answer.isEmpty ? "録音して答える" : "録り直す", systemImage: "mic.fill", action: coach.beginRecording)
                    .buttonStyle(.borderedProminent)
                    .controlSize(.large)
                    .disabled(coach.speaking || coach.waitingToSave)
            } else {
                ProgressView(status)
                    .controlSize(.small)
            }
            Text("回答　文字起こしはここで直せます。直接入力もできます。")
                .font(.subheadline)
            TextEditor(text: $coach.answer)
                .font(.body)
                .frame(minHeight: 90)
                .padding(5)
                .background(.background, in: RoundedRectangle(cornerRadius: 8))
                .overlay(RoundedRectangle(cornerRadius: 8).strokeBorder(.quaternary))
                .accessibilityLabel("回答")
                .disabled(coach.phase.busy || coach.waitingToSave)
            HStack {
                Button("この質問を飛ばす", action: coach.skip)
                Button("練習をやめる") { coach.showReset = true }
                Spacer()
                Button(coach.waitingToSave ? "もう一度保存" : "採点する", systemImage: "checkmark.circle", action: coach.grade)
                    .buttonStyle(.borderedProminent)
                    .disabled(coach.cleanAnswer.isEmpty || coach.speaking)
            }
            .disabled(coach.phase.busy)
        }
        .padding(23)
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 16))
    }

    private var status: String {
        switch coach.phase {
        case .microphone: "マイクを準備しています"
        case .transcription: "文字にしています"
        case .grading: "回答を採点しています"
        default: ""
        }
    }

    private var resultsPanel: some View {
        VStack(alignment: .leading, spacing: 15) {
            HStack(alignment: .firstTextBaseline) {
                Text("練習の結果").font(.title2.bold())
                Spacer()
                if let total = coach.completeScore {
                    Text("合計 \(total) / 60").font(.title2.bold()).foregroundStyle(.teal)
                }
            }
            Text("公式の6項目を参考にした、質疑応答の練習点です。")
                .foregroundStyle(.secondary)
            if coach.deck.count == 6 && coach.completeScore == nil {
                Text("未評価の項目があるため、合計は表示していません。")
                    .foregroundStyle(.secondary)
            }
            ForEach(coach.results.sorted { $0.question.criterion < $1.question.criterion }, id: \.question.id) { result in
                VStack(alignment: .leading, spacing: 6) {
                    HStack {
                        Text(result.criterion).font(.headline)
                        Spacer()
                        Text(result.grade.map { "\($0.score) / 10" } ?? "未評価")
                            .font(.headline.monospacedDigit())
                    }
                    Text(result.question.text).font(.subheadline).foregroundStyle(.secondary)
                    if let grade = result.grade {
                        if !grade.evidence.isEmpty {
                            Text("回答のことば　「\(grade.evidence)」").foregroundStyle(.secondary)
                        }
                        if !grade.good.isEmpty { Label(grade.good, systemImage: "hand.thumbsup") }
                        Label(grade.next, systemImage: "arrow.turn.down.right")
                    }
                }
                .padding(14)
                .background(.background, in: RoundedRectangle(cornerRadius: 10))
            }
            HStack {
                if coach.speaking {
                    Button("読み上げを止める", systemImage: "stop.circle", action: coach.stopSpeaking)
                } else {
                    Button("結果をもう一度聞く", systemImage: "speaker.wave.2", action: coach.readResults)
                }
                Spacer()
                Button("練習を選び直す", action: coach.reset)
            }
        }
        .padding(23)
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 16))
    }
}
