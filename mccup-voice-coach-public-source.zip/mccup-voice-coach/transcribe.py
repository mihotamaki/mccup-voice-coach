"""Read mono Float32 PCM and return the recognized Japanese text as JSON."""
import json
import os
from pathlib import Path
import sys

os.environ.update(HF_HUB_OFFLINE="1", HF_HUB_DISABLE_TELEMETRY="1")

def main():
    import contextlib
    import numpy as np
    from scipy.signal import resample_poly
    from math import gcd

    rate = int(sys.argv[1])
    raw = sys.stdin.buffer.read(4 * rate * 91)
    audio = np.frombuffer(raw, dtype="<f4")
    if audio.size < rate // 2 or np.max(np.abs(audio)) < 0.002:
        return {"text": ""}
    factor = gcd(rate, 16000)
    audio = resample_poly(audio, 16000 // factor, rate // factor)
    with open(os.devnull, "w") as quiet, contextlib.redirect_stdout(quiet):
        if len(sys.argv) == 3 and sys.argv[2] == "cpu":
            import whisper
            model_path = Path.home() / ".cache/whisper/small.pt"
            if not model_path.is_file():
                raise FileNotFoundError
            model = whisper.load_model(str(model_path), device="cpu")
            result = model.transcribe(audio, language="ja", fp16=False, verbose=None,
                                      condition_on_previous_text=False)
        else:
            import mlx_whisper
            hub = Path.home() / ".cache/huggingface/hub"
            model = None
            for name in ("whisper-large-v3-mlx", "whisper-small-mlx"):
                cache = hub / ("models--mlx-community--" + name)
                revision_file = cache / "refs/main"
                if not revision_file.is_file():
                    continue
                revision = revision_file.read_text().strip()
                if not revision.isalnum():
                    continue
                candidate = cache / "snapshots" / revision
                if (candidate / "config.json").is_file() and (candidate / "weights.npz").is_file():
                    model = candidate
                    break
            if model is None:
                raise FileNotFoundError
            result = mlx_whisper.transcribe(audio, path_or_hf_repo=str(model),
                                            language="ja", verbose=None,
                                            condition_on_previous_text=False,
                                            temperature=0)
    segments = result.get("segments", [])
    audible = [s["text"] for s in segments
               if s.get("no_speech_prob", 0) < 0.65 or s.get("avg_logprob", -2) > -0.7]
    return {"text": "".join(audible).strip()}

if __name__ == "__main__":
    try:
        print(json.dumps(main(), ensure_ascii=False))
    except Exception:
        # Diagnostics must not expose the answer text.
        print('{"error":true}')
        sys.exit(1)
