#!/bin/zsh
set -eu
umask 077
cd -- "${0:A:h}"
app="${1:-../マイクラカップ チーム練習.app}"
mkdir -p "$app/Contents/MacOS" "$app/Contents/Resources"
scratch=$(mktemp -d "${TMPDIR:-/tmp}/owase-coach.XXXXXXXX")
trap 'rm -rf -- "$scratch"' EXIT
export CLANG_MODULE_CACHE_PATH="$scratch/clang"
/usr/bin/xcrun swiftc -target arm64-apple-macosx26.0 -module-cache-path "$scratch/swift" \
  -O -parse-as-library CoachApp.swift Practice.swift Audio.swift History.swift -o "$app/Contents/MacOS/OwaseVoiceCoach"
/bin/cp Info.plist "$app/Contents/Info.plist"
/bin/cp questions.json transcribe.py "$app/Contents/Resources/"
/usr/bin/codesign --force --sign - "$app"
/usr/bin/codesign --verify --strict "$app"
