const encoder = new TextEncoder();
const mime = { html: "text/html", css: "text/css", js: "text/javascript", json: "application/json", svg: "image/svg+xml", webmanifest: "application/manifest+json" };
const security = {
  "X-Content-Type-Options": "nosniff",
  "Referrer-Policy": "no-referrer",
  "X-Frame-Options": "DENY",
  "Permissions-Policy": "camera=(), microphone=(self), geolocation=()",
  "Content-Security-Policy": "default-src 'self'; script-src 'self' https://cdn.jsdelivr.net 'wasm-unsafe-eval'; style-src 'self'; connect-src 'self' https://cdn.jsdelivr.net https://huggingface.co https://*.huggingface.co https://*.hf.co; worker-src 'self' blob:; media-src 'self' blob:; img-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'none'",
};

function json(data, status = 200) {
  return Response.json(data, { status, headers: { ...security, "Cache-Control": "no-store" } });
}

function equal(a, b) {
  if (typeof b !== "string" || a.length !== b.length) return false;
  let mismatch = 0;
  for (let i = 0; i < a.length; i++) mismatch |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return mismatch === 0;
}

async function identity(request, keys) {
  const supplied = request.headers.get("authorization")?.match(/^Bearer ([a-f0-9]{64})$/u)?.[1];
  if (!supplied) return null;
  const data = await crypto.subtle.digest("SHA-256", encoder.encode(supplied));
  const digest = Array.from(new Uint8Array(data), n => n.toString(16).padStart(2, "0")).join("");
  if (equal(digest, keys.owner)) return { role: "owner", slot: null };
  const slot = keys.members?.findIndex(key => equal(digest, key)) ?? -1;
  return slot < 0 ? null : { role: "member", slot };
}

const uuid = /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/u;
const base64 = /^[A-Za-z0-9_-]+$/u;

async function api(request, env, url) {
  const roster = env.TEAM_ROSTER ? JSON.parse(env.TEAM_ROSTER) : null;
  const user = await identity(request, roster?.hashes ?? JSON.parse(env.TEAM_HASHES || "{}"));
  if (!user) return json({ error: "forbidden" }, 403);
  const memberTimeline = env["TEAM_TIMELINE_" + user.slot];
  const timeline = user.role !== "member" ? undefined : roster
    ? JSON.parse(memberTimeline || "null")
    : JSON.parse(env.TEAM_TIMELINE || "[]").find(item => item.slot === user.slot);
  const profiles = roster?.profiles ?? JSON.parse(env.TEAM_PROFILES || "[]");
  const historyEpoch = env.PRACTICE_HISTORY_EPOCH || null;
  if (request.method === "GET" && url.pathname === "/api/team") {
    const allowed = user.role === "owner" ? profiles : profiles.filter(item => item.slot === user.slot);
    return json({ ...user, profiles: allowed, timeline, historyEpoch });
  }
  if (request.method === "GET" && url.pathname === "/api/bank") {
    if (!ASSETS["team-questions.json"]) return json({ error: "not configured" }, 404);
    return json(JSON.parse(ASSETS["team-questions.json"]));
  }
  if (request.method === "GET" && url.pathname === "/api/question-audio") {
    const id = url.searchParams.get("id");
    const clip = /^[1-9]\d{0,2}$/u.test(id || "") && BINARY_ASSETS["voice-team-" + id + ".bin"];
    if (!clip) return json({ error: "not found" }, 404);
    return new Response(Uint8Array.from(atob(clip), char => char.charCodeAt(0)), {
      headers: { ...security, "Content-Type": "application/octet-stream", "Cache-Control": "private, no-store" },
    });
  }
  if (url.pathname !== "/api/records") return json({ error: "not found" }, 404);
  const slotText = url.searchParams.get("slot");
  const slot = /^(0|[1-9]\d*)$/u.test(slotText ?? "") ? Number(slotText) : null;
  const teammate = user.role === "member" && user.slot !== slot;
  const mayReadTeammate = request.method === "GET" && Boolean(timeline);
  const registered = profiles.some(profile => profile.slot === slot);
  if (!registered || (teammate && !mayReadTeammate)) return json({ error: "forbidden" }, 403);

  const prefix = (historyEpoch ? "records/v2/" + historyEpoch + "/" : "records/v1/") + slot + "/";
  if (request.method === "GET") {
    const cursor = url.searchParams.get("cursor") || undefined;
    if (cursor && cursor.length > 1000) return json({ error: "invalid cursor" }, 400);
    const page = await env.BUCKET.list({ prefix, limit: 24, cursor });
    const records = await Promise.all(page.objects.map(async ({ key }) => {
      const stored = await env.BUCKET.get(key);
      return stored ? stored.json() : null;
    }));
    return json({ records: records.filter(Boolean), next: page.truncated ? page.cursor : null });
  }
  if (request.method === "POST") {
    if (historyEpoch && request.headers.get("X-Practice-History-Epoch") !== historyEpoch) {
      return json({ error: "history reset" }, 409);
    }
    if (!request.headers.get("content-type")?.startsWith("application/json")) return json({ error: "invalid body" }, 400);
    const body = await request.text();
    if (body.length > 18000) return json({ error: "too large" }, 413);
    let record;
    try { record = JSON.parse(body); } catch { return json({ error: "invalid body" }, 400); }
    if (!record || typeof record.id !== "string" || !uuid.test(record.id)
        || typeof record.iv !== "string" || record.iv.length !== 16 || !base64.test(record.iv)
        || typeof record.data !== "string" || record.data.length < 22 || !base64.test(record.data)) {
      return json({ error: "invalid record" }, 400);
    }
    await env.BUCKET.put(prefix + record.id, JSON.stringify({ id: record.id, iv: record.iv, data: record.data }),
                         { onlyIf: { etagDoesNotMatch: "*" } });
    return json({ ok: true });
  }
  return json({ error: "method not allowed" }, 405);
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (request.method === "GET" && url.pathname === "/public-members.json") {
      try {
        const names = JSON.parse(env.PUBLIC_MEMBER_NAMES ?? "null");
        if (names === null || (Array.isArray(names) && names.length > 0 &&
            names.every(name => typeof name === "string" && name.trim() && name.length <= 18))) {
          return json(names);
        }
      } catch { /* invalid runtime configuration */ }
      return json({ error: "temporarily unavailable" }, 503);
    }
    if (request.method === "GET" && url.pathname === "/practice-concepts.json") {
      try { return json(JSON.parse(env.PRACTICE_CONCEPTS ?? "[]")); }
      catch { return json([]); }
    }
    if (request.method === "GET" && url.pathname === "/history-epoch.json") {
      return json(env.PRACTICE_HISTORY_EPOCH || null);
    }
    if (url.pathname.startsWith("/api/")) {
      try { return await api(request, env, url); }
      catch { return json({ error: "temporarily unavailable" }, 503); }
    }
    const name = url.pathname === "/" ? "index.html" : url.pathname.slice(1);
    const readable = request.method === "GET" || request.method === "HEAD";
    if (readable && !name.endsWith(".bin") && Object.hasOwn(BINARY_ASSETS, name)) {
      const bytes = Uint8Array.from(atob(BINARY_ASSETS[name]), char => char.charCodeAt(0));
      return new Response(request.method === "HEAD" ? null : bytes, {
        headers: { ...security, "Content-Type": name.endsWith(".mp3") ? "audio/mpeg" : "image/png", "Cache-Control": "no-cache" },
      });
    }
    if (!readable || name === "team-questions.json" || !Object.hasOwn(ASSETS, name)) {
      return new Response("Not found", { status: 404, headers: security });
    }
    return new Response(request.method === "HEAD" ? null : ASSETS[name], {
      headers: { ...security, "Content-Type": mime[name.split(".").pop()] + "; charset=utf-8",
        "Cache-Control": "no-cache" },
    });
  },
};
