const encoder = new TextEncoder();
const mime = { html: "text/html", css: "text/css", js: "text/javascript", json: "application/json" };
const security = {
  "X-Content-Type-Options": "nosniff",
  "Referrer-Policy": "no-referrer",
  "X-Frame-Options": "DENY",
  "Permissions-Policy": "camera=(), microphone=(self), geolocation=()",
  "Content-Security-Policy": "default-src 'self'; script-src 'self' https://cdn.jsdelivr.net 'wasm-unsafe-eval'; style-src 'self'; connect-src 'self' https://cdn.jsdelivr.net https://huggingface.co https://*.huggingface.co https://*.hf.co; worker-src 'self' blob:; img-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'none'",
};

function json(data, status = 200) {
  return Response.json(data, { status, headers: { ...security, "Cache-Control": "no-store" } });
}

function equal(a, b) {
  if (typeof b !== "string" || a.length !== b.length) return false;
  let mismatch = 0;
  for (let i = 0; i < a.length; i++) mismatch |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return mismatch === 0;
}

async function identity(request, env) {
  const supplied = request.headers.get("authorization")?.match(/^Bearer ([a-f0-9]{64})$/u)?.[1];
  if (!supplied) return null;
  const data = await crypto.subtle.digest("SHA-256", encoder.encode(supplied));
  const digest = Array.from(new Uint8Array(data), n => n.toString(16).padStart(2, "0")).join("");
  const keys = JSON.parse(env.TEAM_HASHES || "{}");
  if (equal(digest, keys.owner)) return { role: "owner", slot: null };
  const slot = keys.members?.findIndex(key => equal(digest, key)) ?? -1;
  return slot < 0 ? null : { role: "member", slot };
}

const uuid = /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/u;
const base64 = /^[A-Za-z0-9_-]+$/u;
const slotNumber = n => Number.isInteger(n) && n >= 0 && n < 5;

async function api(request, env, url) {
  const user = await identity(request, env);
  if (!user) return json({ error: "forbidden" }, 403);
  const timeline = user.role === "member"
    ? JSON.parse(env.TEAM_TIMELINE || "[]").find(item => item.slot === user.slot)
    : undefined;
  if (request.method === "GET" && url.pathname === "/api/team") {
    const profiles = JSON.parse(env.TEAM_PROFILES || "[]");
    const allowed = user.role === "owner" ? profiles : profiles.filter(item => item.slot === user.slot);
    return json({ ...user, profiles: allowed, timeline });
  }
  if (request.method === "GET" && url.pathname === "/api/bank") {
    if (!ASSETS["team-questions.json"]) return json({ error: "not configured" }, 404);
    return json(JSON.parse(ASSETS["team-questions.json"]));
  }
  if (url.pathname !== "/api/records") return json({ error: "not found" }, 404);
  const slotText = url.searchParams.get("slot");
  const slot = slotText === null || !/^[0-4]$/u.test(slotText) ? null : Number(slotText);
  const teammate = user.role === "member" && user.slot !== slot;
  const mayReadTeammate = request.method === "GET" && Boolean(timeline);
  if (!slotNumber(slot) || (teammate && !mayReadTeammate)) return json({ error: "forbidden" }, 403);

  const prefix = "records/v1/" + slot + "/";
  if (request.method === "GET") {
    const cursor = url.searchParams.get("cursor") || undefined;
    if (cursor && cursor.length > 1000) return json({ error: "invalid cursor" }, 400);
    const page = await env.BUCKET.list({ prefix, limit: 24, cursor });
    const records = await Promise.all(page.objects.map(async ({ key }) => {
      const stored = await env.BUCKET.get(key);
      return stored ? stored.json() : null;
    }));
    return json({ records: records.filter(Boolean), next: page.truncated ? page.cursor : null });
  }
  if (request.method === "POST") {
    if (!request.headers.get("content-type")?.startsWith("application/json")) return json({ error: "invalid body" }, 400);
    const body = await request.text();
    if (body.length > 18000) return json({ error: "too large" }, 413);
    let record;
    try { record = JSON.parse(body); } catch { return json({ error: "invalid body" }, 400); }
    if (!record || typeof record.id !== "string" || !uuid.test(record.id)
        || typeof record.iv !== "string" || record.iv.length !== 16 || !base64.test(record.iv)
        || typeof record.data !== "string" || record.data.length < 22 || !base64.test(record.data)) {
      return json({ error: "invalid record" }, 400);
    }
    await env.BUCKET.put(prefix + record.id, JSON.stringify({ id: record.id, iv: record.iv, data: record.data }),
                         { onlyIf: { etagDoesNotMatch: "*" } });
    return json({ ok: true });
  }
  return json({ error: "method not allowed" }, 405);
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname.startsWith("/api/")) {
      try { return await api(request, env, url); }
      catch { return json({ error: "temporarily unavailable" }, 503); }
    }
    const name = url.pathname === "/" ? "index.html" : url.pathname.slice(1);
    if ((request.method !== "GET" && request.method !== "HEAD") || name === "team-questions.json" || !Object.hasOwn(ASSETS, name)) {
      return new Response("Not found", { status: 404, headers: security });
    }
    return new Response(request.method === "HEAD" ? null : ASSETS[name], {
      headers: { ...security, "Content-Type": mime[name.split(".").pop()] + "; charset=utf-8",
        "Cache-Control": "no-cache" },
    });
  },
};
