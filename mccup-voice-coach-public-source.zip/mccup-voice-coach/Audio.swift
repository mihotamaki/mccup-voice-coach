import AVFoundation
import Darwin
import Foundation

// The audio callback runs off the main thread. Keep at most 90 seconds in RAM.
final class Samples: @unchecked Sendable {
    private let lock = NSLock()
    private var data = Data()
    private let limit: Int
    init(rate: Int) { limit = rate * 90 * MemoryLayout<Float>.size }

    func append(_ buffer: AVAudioPCMBuffer) {
        guard let channel = buffer.floatChannelData?[0] else { return }
        lock.lock()
        defer { lock.unlock() }
        let count = min(Int(buffer.frameLength) * MemoryLayout<Float>.size, limit - data.count)
        if count > 0 { data.append(UnsafeRawBufferPointer(start: channel, count: count).bindMemory(to: UInt8.self)) }
    }

    func take() -> Data {
        lock.lock()
        defer { lock.unlock() }
        let result = data
        data = Data()
        return result
    }
}

@MainActor
final class Recorder {
    private var engine: AVAudioEngine?
    private var samples: Samples?
    private var rate = 0

    func start() async throws {
        guard await AVCaptureDevice.requestAccess(for: .audio) else { throw PracticeError.microphone }
        let engine = AVAudioEngine()
        let input = engine.inputNode
        let format = input.outputFormat(forBus: 0)
        guard format.sampleRate > 0, format.channelCount > 0,
              format.commonFormat == .pcmFormatFloat32, !format.isInterleaved else {
            throw PracticeError.microphone
        }
        rate = Int(format.sampleRate.rounded())
        let samples = Samples(rate: rate)
        input.installTap(onBus: 0, bufferSize: 2048, format: format) { buffer, _ in samples.append(buffer) }
        do { try engine.start() } catch {
            input.removeTap(onBus: 0)
            throw PracticeError.microphone
        }
        self.samples = samples
        self.engine = engine
    }

    func stop() -> (Data, Int) {
        if let engine {
            engine.inputNode.removeTap(onBus: 0)
            engine.stop()
        }
        engine = nil
        let data = samples?.take() ?? Data()
        samples = nil
        return (data, rate)
    }
}

enum Transcriber {
    private struct Reply: Decodable { let text: String }

    static func read(_ data: Data, rate: Int, script: URL) async throws -> String {
        try await Task.detached(priority: .userInitiated) {
            if let reply = run(data, rate: rate, script: script, cpu: false) { return reply }
            if let reply = run(data, rate: rate, script: script, cpu: true) { return reply }
            throw PracticeError.transcription
        }.value
    }

    private static func run(_ data: Data, rate: Int, script: URL, cpu: Bool) -> String? {
        let process = Process()
        let installedPython = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("OwaseVoiceCoach/runtime/bin/python3")
        process.executableURL = FileManager.default.isExecutableFile(atPath: installedPython.path)
            ? installedPython : URL(fileURLWithPath: "/usr/bin/python3")
        process.arguments = [script.path, String(rate)] + (cpu ? ["cpu"] : [])
        let input = Pipe()
        let output = Pipe()
        process.standardInput = input
        process.standardOutput = output
        process.standardError = FileHandle.nullDevice
        do { try process.run() } catch { return nil }
        // Send audio on a separate queue while draining stdout.
        let writer = input.fileHandleForWriting
        _ = fcntl(writer.fileDescriptor, F_SETNOSIGPIPE, 1)
        DispatchQueue.global(qos: .userInitiated).async {
            defer { try? writer.close() }
            try? writer.write(contentsOf: data)
        }
        let reply = output.fileHandleForReading.readDataToEndOfFile()
        process.waitUntilExit()
        guard process.terminationStatus == 0 else { return nil }
        return try? JSONDecoder().decode(Reply.self, from: reply).text
    }
}
