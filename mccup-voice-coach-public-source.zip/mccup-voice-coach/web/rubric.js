export const criteria = ["テーマ性", "調査力", "構想力", "計画遂行力", "技術力", "表現力"];
const tips = [
  "次は、どんな人の暮らしをよくしたいか、ワールドの場所を一つ挙げて話してみよう。",
  "次は、何をどう知ったかと、その話を作品にどう生かしたかをつないでみよう。",
  "次は、そのアイデアを選んだ理由を一つ足してみよう。",
  "次は、困ったことに対して、自分やチームがした行動を一つ足してみよう。",
  "次は、仕掛けを操作した後に起きることを順に話してみよう。",
  "次は、見る人に伝えたいことを、見せたい場面とセットで話してみよう。",
];
const examples = [
  "大会テーマ。人口と年齢が変わる社会の課題、誰の暮らしを変えるか、作品に作った場所や仕掛け。",
  "取材、聞き取り、調べた資料、見学、体験、分かったこと、自分たちで考えたこと。",
  "理想のまち、自分たちのアイデア、思いついたきっかけ、そう考えた理由。",
  "チームで担当や計画を決め、困ったことを協力して乗り越えた、自分がしたこと。",
  "動く順番、仕掛けを作る技術やコマンド、操作、工夫、動作確認、何に役立つか。",
  "作品の魅力、見てほしい場面、伝えたいこと、動画や写真や模型を選んだ理由。",
];
const specific = {
  6: "次は、どの模型について話すかを先に言ってから、作った順番を話してみよう。",
  27: "次は、地域の人から聞いた話と、ワールドのどこを変えたかをつないで話してみよう。",
  57: "鏡の間では出る人がランダムで、希望の城では次の行動を自分で選べます。二つに分けて話してみよう。",
  107: "次は、操作、仕掛けの動き、最後に起きることの順に、一つずつ話してみよう。",
  117: "次は、困ったときに自分がした行動か、みんなで役割を分けた例を一つ足してみよう。",
  137: "次は、写真を一枚選んで、見る人に何を感じてほしかったかを一言で話してみよう。",
  147: "次は、今できることと、これから実現したいことを一つずつ分けて話してみよう。",
};
const strongTip = "次は、いちばん伝えたい答えを最初の一文にしてみよう。";
export const spokenTips = [...new Set([...tips, ...Object.values(specific), strongTip])];
const weak = /^(?:(?:えーと|うーん)[、, ]*)?(?:わかりません|分かりません|まだわかりません|知りません|知りませんでした|特にありません|なし|うーん|えーと|はい|いいえ)[。！？!?、,\s]*$/u;
const relation = /から|ので|ため|すると|それで|そこで|たとえば|例えば|まず|次に|そのあと|最後に|ように|たら|結果/u;
const concreteDetail = /[0-9一二三四五六七八九十]+(?:人|回|日|時間|分|か所|個|段|台|種類)|けんか|喧嘩|意見が(?:割|合わ|違|分か)|少子高齢|お年寄り|車いす|空き家|廃校|病院|学校|浮島|商店街|鏡の間|希望の城|球体|模型|地図|看板|写真|字幕|アンケート|レッドストーン|回路|コマンド|ボタン|レバー|ゲート/u;
const action = /聞き取|聞いて|聞きま|聞いた|相談|話し合|役割を分|担当を|手分け|比べ|書き出|押[すし]|置[くい]|切り替|試[すし]|直[すし]|取り入|見直|変え|残[すし]|工夫し|つな[ぐいげ]|調べ|選[ぶびん]|見せ|教わ|教えて/u;
const outcome = /ようにな|できるよう|完成|作りき|分か[っり]|わか[っり]|気[づ付]|[扉門]が開|動くよう|移動で|解決|仲直り|まとま|変わ[っり]/u;
const irrelevance = "今日の夕ご飯や天気について。作品や質問とは関係のない雑談です。";

function normalizeAnswer(question, answer) {
  let text = answer.normalize("NFKC").replace(/[\u3000\t]+/gu, " ").trim();
  if (question.criterion === 3) {
    text = text.replace(/チーム感(?=[のではに])/gu, "チーム間").replace(/話し愛/gu, "話し合い");
  }
  if (question.criterion === 4) {
    text = text.replace(/レット[ ]?ストーン|レッド +ストーン/gu, "レッドストーン")
      .replace(/(レッドストーンの)海路/gu, "$1回路");
  }
  if (question.id === 57) text = text.replace(/鏡の魔/gu, "鏡の間").replace(/希望の白/gu, "希望の城");
  return text;
}

function cosine(a, b) {
  return a.reduce((total, n, index) => total + n * b[index], 0);
}

export function inputsFor(question, answer) {
  const text = normalizeAnswer(question, answer);
  const pieces = text.split(/[。！？!?\n]+/u).map(piece => piece.trim()).filter(piece => piece.length >= 6).slice(0, 8);
  return [
    "query: " + question.text,
    "query: " + (question.guidance || examples[question.criterion]),
    "query: " + irrelevance,
    "passage: " + text,
    ...(pieces.length > 1 ? pieces.map(piece => "passage: " + piece) : []),
  ];
}

const reasons = [
  [
    [/大会テーマ|少子高齢|高齢化|人口|年齢|世代|子ども|お年寄り/u, "大会テーマにつながる人や社会に触れています。"],
    [/困[るっり]|不便|課題|問題|不足|危険|減[るっり]|変化/u, "まちや暮らしの課題を挙げています。"],
    [/どうすれば|どうしたら|どんな.*できる|安心|暮らしやす|住みやす|助け|役立|できるよう/u, "暮らしをどう良くしたいかを話しています。"],
    [/ワールド|建物|施設|広場|公園|城|学校|病院|駅|道|乗り物|仕掛け/u, "ワールドの場所や仕掛けを挙げています。"],
  ],
  [
    [/本で|資料|サイト|ネット|インターネット|動画で|データ|アンケート|地図/u, "調べるときに使った資料や情報源に触れています。"],
    [/取材|聞き取|インタビュー|聞いた|聞きま|教えてもら|見学|体験|見に行|実際に/u, "人に聞いたことや実際の体験に触れています。"],
    [/分か[っり]|わか[っり]|知[っり]|気[づ付]|初めて知|比べ|学[んび]/u, "調べたり体験したりして気づいたことを話しています。"],
    [/生か|活か|取り入|反映|参考に|見直|変えた|変えま/u, "調べたことを作品に生かした工夫に触れています。"],
  ],
  [
    [/アイデア|思いつ|考え|発想|案を|提案/u, "自分たちで考えたアイデアに触れています。"],
    [/理想|こんなまち|どんなまち|できるよう|できたら|を目指/u, "実現したい姿を話しています。"],
    [/設計|下書き|スケッチ|絵に|図に|模型|文章に|書き出/u, "アイデアを絵や図などで形にしています。"],
    [/作りた[いか]|きっかけ|と思った|選んだ|したかった|願い|大切に/u, "なぜそのアイデアを形にしたいかに触れています。"],
  ],
  [
    [/計画|予定|目標|締[め切]|期限|スケジュール|順番を決|工程/u, "完成までの計画や目標を話しています。"],
    [/担当|役割|分担|手分け|協力|話し合|手伝|自分は|私は|ぼくは|僕は/u, "自分の役割やチームの協力に触れています。"],
    [/トラブル|失敗|困[っり]|うまく|間に合|やり直|難しか|大変|止まっ|けんか|喧嘩|意見が(?:割|合わ|違|分か)/u, "途中で起きた困りごとを挙げています。"],
    [/工夫|直した|直しま|見直|乗り越|切り替|試し直|完成|最後まで|作りき/u, "完成に向けて工夫した行動に触れています。"],
  ],
  [
    [/コマンド|レッドストーン|プログラム|メイクコード|MakeCode|回路|ブロック|仕掛け/u, "使った技術や仕掛けに触れています。"],
    [/押[すし]|引く|置く|入力|操作|スイッチ|ボタン|レバー|乗る/u, "仕掛けをどう操作するかを話しています。"],
    [/動[くきい]|変わ|開[くきい]|出[るてた]|光[るりっ]|移動|表示|切り替|テレポート/u, "操作したあとに起きる動きを話しています。"],
    [/確認|テスト|試した|試しま|調整|直した|直しま|使いやす|役立|自動/u, "技術を使った工夫や動作確認に触れています。"],
  ],
  [
    [/伝え|見せ|見てほし|感じて|わかって|分かって|魅力|知ってほし/u, "見る人に何を伝えたいかに触れています。"],
    [/発表で|発表に使|写真|動画|スライド|画面|模型|看板|字幕|実演|案内|見せ方/u, "伝えるために使った方法や資料を挙げています。"],
    [/場面|見どころ|工夫|選[んび]|目立|強調|色|拡大|アップ|切り替/u, "見せ方の工夫や見せたい場面を挙げています。"],
    [/聞く人|聞いている人|見る人|見た人|分かりやす|わかりやす|短[くい]|順番|最初に|最後に/u, "聞き手を意識した伝え方に触れています。"],
  ],
];
const noEvidence = "この回答からは、この観点の根拠を確認できませんでした。";
const strongEvidence = [
  "暮らしの課題と、ワールドで形にした工夫をつないでいます。",
  "調べ方、気づいたこと、作品に生かした工夫をつないでいます。",
  "理想の姿と、それを形にしたい理由を話しています。",
  "計画、途中で困ったこと、完成までの工夫を話しています。",
  "使った技術と、操作から結果までの流れを話しています。",
  "伝えたいことと、聞き手に合わせた見せ方を話しています。",
];
const contextualEvidence = "質問の内容に沿って、自分のことばで答えています。";
const exampleEvidence = "質問に沿った具体例や、実際にしたことを挙げています。";
const connectedEvidence = "具体例に加えて、理由や手順のつながりを説明しています。";
const mixedUp = "二つの場所で何が起きるか、もう一度整理すると伝わりやすくなります。";
export const spokenReasons = [...new Set([
  noEvidence, ...reasons.flatMap(row => row.map(([, reason]) => reason)), ...strongEvidence,
  contextualEvidence, exampleEvidence, connectedEvidence, mixedUp,
])];

const conceptText = text => text.normalize("NFKC").toLowerCase().replace(/[\s、。!?「」『』×・]/gu, "");

function conceptMatches(answer, groups) {
  const text = conceptText(answer);
  return groups.flatMap(group => {
    const match = group.find(terms => terms.some(term => text.includes(conceptText(term))));
    return match ? [match[0]] : [];
  });
}

export function assess(question, answer, vectors, concepts = []) {
  const text = normalizeAnswer(question, answer);
  const tip = specific[question.id] || tips[question.criterion];
  if (weak.test(text) || !/[\p{L}\p{N}]/u.test(text)) {
    return { rating: { stars: 0, reason: noEvidence }, score100: 0, next: tip };
  }

  const [query, guide, unrelated, passage, ...sentences] = vectors;
  const relevance = candidate => Math.max(cosine(query, candidate), cosine(guide, candidate)) - cosine(unrelated, candidate);
  const whole = relevance(passage);
  const best = Math.max(whole, ...sentences.map(relevance));
  const signals = reasons[question.criterion].filter(([pattern]) => pattern.test(text));
  // A relevant sentence can support a noisy transcript even when no rubric word survived.
  const clear = whole >= 0.065 || best >= 0.085 || (signals.length > 0 && best >= 0.025);
  const hasExample = concreteDetail.test(text);
  const hasAction = action.test(text);
  const hasResult = outcome.test(text);
  const mapTerms = conceptMatches(text, concepts);
  const conceptExample = mapTerms.length > 0 && best >= 0.01 && text.length >= 14 &&
    (hasExample || hasAction || hasResult);
  const related = clear || best >= 0.025 || (signals.length > 0 && best >= -0.025) || conceptExample;
  const linked = relation.test(text) && text.length >= 22 && (hasAction || hasExample || hasResult);
  const details = Number(hasExample) * 10 + Number(hasAction) * 9 + Number(linked) * 8 + Number(hasResult) * 6;

  let score100 = related ? Math.min(100, (clear ? 68 : 57) + details) : 30;
  let reason = noEvidence;
  if (related) {
    if (linked && signals.length === reasons[question.criterion].length) reason = strongEvidence[question.criterion];
    else if (linked) reason = connectedEvidence;
    else reason = signals.at(-1)?.[1] ?? (hasExample || hasAction ? exampleEvidence : contextualEvidence);
  }

  if (question.id === 57) {
    const mirror = text.match(/鏡の間([^。！？!?\n]*)/u)?.[1].split("希望の城")[0] ?? "";
    const castle = text.match(/希望の城([^。！？!?\n]*)/u)?.[1].split("鏡の間")[0] ?? "";
    if (/(?:人物|人|誰).*(?:自分で|自由に)選べます/u.test(mirror) ||
        /(?:行動|したいこと|やること).*ランダム(?:です|で決ま)/u.test(castle)) {
      score100 = Math.min(score100, 60);
      reason = mixedUp;
    }
  }

  const base = score100;
  const terms = related && reason !== mixedUp ? mapTerms : [];
  const points = Math.min(5 * terms.length, 100 - base);
  score100 += points;
  const stars = [25, 50, 65, 78, 90].filter(minimum => score100 >= minimum).length;
  return {
    rating: { stars, reason },
    score100,
    next: base >= 90 ? strongTip : tip,
    ...(terms.length ? { conceptBonus: { terms, points } } : {}),
  };
}
