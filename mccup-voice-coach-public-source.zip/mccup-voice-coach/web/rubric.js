export const criteria = ["テーマ性", "調査力", "構想力", "計画遂行力", "技術力", "表現力"];
const tips = [
  "次は、どんな人の暮らしをよくしたいか、ワールドの場所を一つ挙げて話してみよう。",
  "次は、何をどう知ったかと、その話を作品にどう生かしたかをつないでみよう。",
  "次は、そのアイデアを選んだ理由を一つ足してみよう。",
  "次は、困ったことに対して、自分やチームがした行動を一つ足してみよう。",
  "次は、仕掛けを操作した後に起きることを順に話してみよう。",
  "次は、見る人に伝えたいことを、見せたい場面とセットで話してみよう。",
];
const examples = [
  "大会テーマ。人口と年齢が変わる社会の課題、誰の暮らしを変えるか、作品に作った場所や仕掛け。",
  "取材、聞き取り、調べた資料、見学、体験、分かったこと、自分たちで考えたこと。",
  "理想のまち、自分たちのアイデア、思いついたきっかけ、そう考えた理由。",
  "チームで担当や計画を決め、困ったことを協力して乗り越えた、自分がしたこと。",
  "動く順番、仕掛けを作る技術やコマンド、操作、工夫、動作確認、何に役立つか。",
  "作品の魅力、見てほしい場面、伝えたいこと、動画や写真や模型を選んだ理由。",
];
const specific = {
  6: "次は、どの模型について話すかを先に言ってから、作った順番を話してみよう。",
  27: "次は、地域の人から聞いた話と、ワールドのどこを変えたかをつないで話してみよう。",
  57: "鏡の間では出る人がランダムで、希望の城では次の行動を自分で選べます。二つに分けて話してみよう。",
  107: "次は、操作、仕掛けの動き、最後に起きることの順に、一つずつ話してみよう。",
  117: "次は、困ったときに自分がした行動か、みんなで役割を分けた例を一つ足してみよう。",
  137: "次は、写真を一枚選んで、見る人に何を感じてほしかったかを一言で話してみよう。",
  147: "次は、今できることと、これから実現したいことを一つずつ分けて話してみよう。",
};
const strongTip = "次は、いちばん伝えたい答えを最初の一文にしてみよう。";
export const spokenTips = [...new Set([...tips, ...Object.values(specific), strongTip])];
const weak = /^(?:わかりません|分かりません|まだわかりません|知りません|知りませんでした|特にありません|なし|うーん|えーと)[。！？!？\s]*$/u;
const detail = /から|ので|ため|たとえば|例えば|そのあと|最初に|とき|しました|ました|使った|考えた|作った|聞いた|教わ|調べ|選ん|変え|思い|一緒に|工夫|図|場|人/u;
const relation = /から|ので|ため|すると|それで|そこで|たとえば|例えば|まず|次に|そのあと|結果|という/u;
const irrelevance = "今日の夕ご飯は何ですか。作品や質問とは関係のない雑談です。";

function cosine(a, b) {
  return a.reduce((total, n, index) => total + n * b[index], 0);
}

export function inputsFor(question, answer) {
  const pieces = answer.split(/[。！？\n]+/u).map(s => s.trim()).filter(Boolean).slice(0, 12);
  const questionText = question.id === 57
    ? "鏡の間では現れる人物がランダムで、希望の城では次の行動を自分で選べます。"
    : question.text;
  return [
    "query: " + questionText,
    "query: " + (question.guidance || examples[question.criterion]),
    "query: " + irrelevance,
    "passage: " + answer,
    ...pieces.map(piece => "passage: " + piece),
  ];
}

export function assess(question, answer, vectors) {
  const tip = specific[question.id] || tips[question.criterion];
  if (weak.test(answer)) return { score: 1, evidence: "", good: "", next: tip };
  const [query, guide, unrelated, passage, ...sentences] = vectors;
  const questionFit = cosine(query, passage);
  const guideFit = cosine(guide, passage);
  const unrelatedFit = cosine(unrelated, passage);
  const fit = questionFit - unrelatedFit;
  const answerHasDetail = detail.test(answer);
  const connectsIdeas = relation.test(answer);
  let score = fit < -0.025 && guideFit < 0.75 ? 2 : fit < 0.008 ? 3 : fit < 0.04 ? 4 : 5;
  if (score >= 4 && answerHasDetail) score += 1;
  if (score >= 5 && guideFit >= 0.79) score += 1;
  if (score >= 5 && connectsIdeas) score += 1;
  if (score >= 6 && questionFit >= 0.83 && guideFit >= 0.82) score += 1;
  if (score === 9 && fit >= 0.14 && connectsIdeas) score = 10;

  if (question.id === 57) {
    const mirror = /鏡の間[^。！？\n]*(?:人|人物|誰)[^。！？\n]*(?:自分で選|自由に選)/u;
    const castle = /希望の城[^。！？\n]*(?:行動|したいこと|やること)[^。！？\n]*ランダム/u;
    if (mirror.test(answer) || castle.test(answer)) score = Math.min(score, 4);
  }
  const pieces = answer.split(/[。！？\n]+/u).map(s => s.trim()).filter(Boolean).slice(0, 12);
  let best = -1;
  let evidence = "";
  sentences.forEach((sentence, i) => {
    const relevance = cosine(guide, sentence) + cosine(query, sentence);
    if (pieces[i] && relevance > best) { best = relevance; evidence = pieces[i]; }
  });
  const next = score >= 9 ? strongTip : tip;
  return { score, evidence: score >= 5 ? evidence : "",
    good: score >= 5 && evidence ? "「" + evidence + "」と、自分のことばで話せました。" : "", next };
}
