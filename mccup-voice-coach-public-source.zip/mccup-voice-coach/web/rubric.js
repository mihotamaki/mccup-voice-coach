export const criteria = ["テーマ性", "調査力", "構想力", "計画遂行力", "技術力", "表現力"];
const tips = [
  "次は、どんな人の暮らしをよくしたいか、ワールドの場所を一つ挙げて話してみよう。",
  "次は、何をどう知ったかと、その話を作品にどう生かしたかをつないでみよう。",
  "次は、そのアイデアを選んだ理由を一つ足してみよう。",
  "次は、困ったことに対して、自分やチームがした行動を一つ足してみよう。",
  "次は、仕掛けを操作した後に起きることを順に話してみよう。",
  "次は、見る人に伝えたいことを、見せたい場面とセットで話してみよう。",
];
const examples = [
  "大会テーマ。人口と年齢が変わる社会の課題、誰の暮らしを変えるか、作品に作った場所や仕掛け。",
  "取材、聞き取り、調べた資料、見学、体験、分かったこと、自分たちで考えたこと。",
  "理想のまち、自分たちのアイデア、思いついたきっかけ、そう考えた理由。",
  "チームで担当や計画を決め、困ったことを協力して乗り越えた、自分がしたこと。",
  "動く順番、仕掛けを作る技術やコマンド、操作、工夫、動作確認、何に役立つか。",
  "作品の魅力、見てほしい場面、伝えたいこと、動画や写真や模型を選んだ理由。",
];
const specific = {
  6: "次は、どの模型について話すかを先に言ってから、作った順番を話してみよう。",
  27: "次は、地域の人から聞いた話と、ワールドのどこを変えたかをつないで話してみよう。",
  57: "鏡の間では出る人がランダムで、希望の城では次の行動を自分で選べます。二つに分けて話してみよう。",
  107: "次は、操作、仕掛けの動き、最後に起きることの順に、一つずつ話してみよう。",
  117: "次は、困ったときに自分がした行動か、みんなで役割を分けた例を一つ足してみよう。",
  137: "次は、写真を一枚選んで、見る人に何を感じてほしかったかを一言で話してみよう。",
  147: "次は、今できることと、これから実現したいことを一つずつ分けて話してみよう。",
};
const strongTip = "次は、いちばん伝えたい答えを最初の一文にしてみよう。";
export const spokenTips = [...new Set([...tips, ...Object.values(specific), strongTip])];
const weak = /^(?:わかりません|分かりません|まだわかりません|知りません|知りませんでした|特にありません|なし|うーん|えーと)[。！？!？\s]*$/u;
const detail = /から|ので|ため|たとえば|例えば|そのあと|最初に|とき|しました|ました|使った|考えた|作った|聞いた|教わ|調べ|選ん|変え|思い|一緒に|工夫|図|場|人/u;
const relation = /から|ので|ため|すると|それで|そこで|たとえば|例えば|まず|次に|そのあと|結果|という/u;
const irrelevance = "今日の夕ご飯は何ですか。作品や質問とは関係のない雑談です。";

function cosine(a, b) {
  return a.reduce((total, n, index) => total + n * b[index], 0);
}

export function inputsFor(question, answer) {
  const pieces = answer.split(/[。！？\n]+/u).map(s => s.trim()).filter(Boolean).slice(0, 12);
  const questionText = question.id === 57
    ? "鏡の間では現れる人物がランダムで、希望の城では次の行動を自分で選べます。"
    : question.text;
  return [
    "query: " + questionText,
    "query: " + (question.guidance || examples[question.criterion]),
    "query: " + irrelevance,
    "passage: " + answer,
    ...pieces.map(piece => "passage: " + piece),
  ];
}

function questionFeedback(question, answer, vectors) {
  const tip = specific[question.id] || tips[question.criterion];
  if (weak.test(answer)) return { score: 1, evidence: "", good: "", next: tip };
  const [query, guide, unrelated, passage, ...sentences] = vectors;
  const questionFit = cosine(query, passage);
  const guideFit = cosine(guide, passage);
  const unrelatedFit = cosine(unrelated, passage);
  const fit = questionFit - unrelatedFit;
  const answerHasDetail = detail.test(answer);
  const connectsIdeas = relation.test(answer);
  let score = fit < -0.025 && guideFit < 0.75 ? 2 : fit < 0.008 ? 3 : fit < 0.04 ? 4 : 5;
  if (score >= 4 && answerHasDetail) score += 1;
  if (score >= 5 && guideFit >= 0.79) score += 1;
  if (score >= 5 && connectsIdeas) score += 1;
  if (score >= 6 && questionFit >= 0.83 && guideFit >= 0.82) score += 1;
  if (score === 9 && fit >= 0.14 && connectsIdeas) score = 10;

  if (question.id === 57) {
    const mirror = /鏡の間[^。！？\n]*(?:人|人物|誰)[^。！？\n]*(?:自分で選|自由に選)/u;
    const castle = /希望の城[^。！？\n]*(?:行動|したいこと|やること)[^。！？\n]*ランダム/u;
    if (mirror.test(answer) || castle.test(answer)) score = Math.min(score, 4);
  }
  const pieces = answer.split(/[。！？\n]+/u).map(s => s.trim()).filter(Boolean).slice(0, 12);
  let best = -1;
  let evidence = "";
  sentences.forEach((sentence, i) => {
    const relevance = cosine(guide, sentence) + cosine(query, sentence);
    if (pieces[i] && relevance > best) { best = relevance; evidence = pieces[i]; }
  });
  const next = score >= 9 ? strongTip : tip;
  return { score, evidence: score >= 5 ? evidence : "",
    good: score >= 5 && evidence ? "「" + evidence + "」と、自分のことばで話せました。" : "", next };
}

const reasons = [
  [
    [/大会テーマ|少子高齢|高齢化|人口|年齢|世代|子ども|お年寄り/u, "大会テーマにつながる人や社会に触れています。"],
    [/困[るっり]|不便|課題|問題|不足|危険|減[るっり]|変化/u, "まちや暮らしの課題を挙げています。"],
    [/どうすれば|どうしたら|どんな.*できる|安心|暮らしやす|住みやす|助け|役立|できるよう/u, "暮らしをどう良くしたいかを話しています。"],
    [/ワールド|建物|施設|広場|公園|城|学校|病院|駅|道|乗り物|仕掛け/u, "ワールドの場所や仕掛けを挙げています。"],
  ],
  [
    [/本で|資料|サイト|ネット|インターネット|動画で|データ|アンケート|地図/u, "調べるときに使った資料や情報源に触れています。"],
    [/取材|聞き取|インタビュー|聞いた|聞きま|教えてもら|見学|体験|見に行|実際に/u, "人に聞いたことや実際の体験に触れています。"],
    [/分か[っり]|わか[っり]|知[っり]|気[づ付]|初めて知|比べ|学[んび]/u, "調べたり体験したりして気づいたことを話しています。"],
    [/生か|活か|取り入|反映|参考に|見直|変えた|変えま/u, "調べたことを作品に生かした工夫に触れています。"],
  ],
  [
    [/アイデア|思いつ|考え|発想|案を|提案/u, "自分たちで考えたアイデアに触れています。"],
    [/理想|こんなまち|どんなまち|できるよう|できたら|を目指/u, "実現したい姿を話しています。"],
    [/設計|下書き|スケッチ|絵に|図に|模型|文章に|書き出/u, "アイデアを絵や図などで形にしています。"],
    [/作りた[いか]|きっかけ|と思った|選んだ|したかった|願い|大切に/u, "なぜそのアイデアを形にしたいかに触れています。"],
  ],
  [
    [/計画|予定|目標|締[め切]|期限|スケジュール|順番を決|工程/u, "完成までの計画や目標を話しています。"],
    [/担当|役割|分担|手分け|協力|話し合|手伝|自分は|私は|ぼくは|僕は/u, "自分の役割やチームの協力に触れています。"],
    [/トラブル|失敗|困[っり]|うまくい|間に合|やり直|難しか|大変|止まっ/u, "途中で起きた困りごとを挙げています。"],
    [/工夫|直した|直しま|見直|乗り越|切り替|試し直|完成|最後まで|作りき/u, "完成に向けて工夫した行動に触れています。"],
  ],
  [
    [/コマンド|レッドストーン|プログラム|メイクコード|MakeCode|回路|ブロック|仕掛け/u, "使った技術や仕掛けに触れています。"],
    [/押[すし]|引く|置く|入力|操作|スイッチ|ボタン|レバー|乗る/u, "仕掛けをどう操作するかを話しています。"],
    [/動[くきい]|変わ|開[くきい]|出[るてた]|光[るりっ]|移動|表示|切り替|テレポート/u, "操作したあとに起きる動きを話しています。"],
    [/確認|テスト|試した|試しま|調整|直した|直しま|使いやす|役立|自動/u, "技術を使った工夫や動作確認に触れています。"],
  ],
  [
    [/伝え|見せ|見てほし|感じて|わかって|分かって|魅力|知ってほし/u, "見る人に何を伝えたいかに触れています。"],
    [/発表で|発表に使|写真|動画|スライド|画面|模型|看板|字幕|実演|案内|見せ方/u, "伝えるために使った方法や資料を挙げています。"],
    [/場面|見どころ|工夫|選[んび]|目立|強調|色|拡大|アップ|切り替/u, "見せ方の工夫や見せたい場面を挙げています。"],
    [/聞く人|聞いている人|見る人|見た人|分かりやす|わかりやす|短[くい]|順番|最初に|最後に/u, "聞き手を意識した伝え方に触れています。"],
  ],
];
const noEvidence = "この回答からは、この観点の根拠を確認できませんでした。";
const strongEvidence = [
  "暮らしの課題と、ワールドで形にした工夫をつないでいます。",
  "調べ方、気づいたこと、作品に生かした工夫をつないでいます。",
  "理想の姿と、それを形にしたい理由を話しています。",
  "計画、途中で困ったこと、完成までの工夫を話しています。",
  "使った技術と、操作から結果までの流れを話しています。",
  "伝えたいことと、聞き手に合わせた見せ方を話しています。",
];
export const spokenReasons = [...new Set([noEvidence, ...reasons.flatMap(row => row.map(([, reason]) => reason)), ...strongEvidence])];

export function overallScore(assessment) {
  if (assessment.some(row => row === null)) return null;
  const stars = assessment.reduce((sum, row) => sum + row.stars, 0);
  return Math.round(100 * stars / (criteria.length * 5));
}

export function assess(question, answer, vectors) {
  const feedback = questionFeedback(question, answer, vectors);
  const assessment = reasons.map((signals, index) => {
    const matches = signals.map(([pattern]) => feedback.score > 2 && pattern.test(answer));
    if (index === 1 && !matches[0] && !matches[1]) matches.fill(false, 2);
    if (index === 3 && !matches[0] && !matches[1] && !matches[2]) matches[3] = false;
    if (index >= 4 && !matches[0] && !matches[1]) matches.fill(false, 2);
    const stars = matches.filter(Boolean).length;
    const connectsEvidence = stars === signals.length && relation.test(answer);
    const last = matches.lastIndexOf(true);
    return {
      stars: stars + Number(connectsEvidence),
      reason: connectsEvidence ? strongEvidence[index] : signals[last]?.[1] ?? noEvidence,
    };
  });
  const next = assessment[question.criterion].stars >= 4 ? strongTip : feedback.next;
  return { assessment, overall: overallScore(assessment), good: feedback.good, next };
}
