import { openHistory } from "./history.js";
import { assess, criteria, inputsFor } from "./rubric.js";
import { connectTeam, leaveTeam } from "./sync.js";

const byId = id => document.getElementById(id);
const view = byId("view");
let names = Array.from({ length: 5 }, (_, id) => ({ id, name: "メンバー " + (id + 1) }));
let active = 0;
let screen = "practice";
let bank = [];
let store;
let team;
let deck = [];
let results = [];
let session;
let busy = false;
let recorder = null;
let recordingTimer;
let audioContext;
let model;
let modelJob;
let failureRecord = null;
let historyVersion = 0;
let historyMember = null;
let historyView;
let flushing;

const memberName = id => names.find(member => member.id === id)?.name || "メンバー";
const activeName = () => memberName(active);
const inPractice = () => deck.length > results.length;

function message(value = "") {
  byId("status").textContent = value;
  byId("status").hidden = !value;
}

function renderTabs() {
  const filtering = Boolean(team) && screen === "history";
  const options = filtering ? [{ id: null, name: "みんな" }, ...names] :
    team?.role === "member" ? names.filter(member => member.id === team.slot) : names;
  const buttons = options.map(member => {
    const button = document.createElement("button");
    button.type = "button";
    button.textContent = member.name;
    button.setAttribute("aria-pressed", String((filtering ? historyMember : active) === member.id));
    button.disabled = busy || inPractice();
    button.onclick = () => {
      stopSpeech();
      if (filtering) historyMember = member.id;
      else {
        active = member.id;
        deck = []; results = [];
      }
      message();
      render();
    };
    return button;
  });
  const members = byId("members");
  members.setAttribute("aria-label", filtering ? "履歴を絞り込む" : "練習するメンバー");
  members.replaceChildren(...buttons);
  for (const button of document.querySelectorAll("[data-screen]")) {
    button.setAttribute("aria-pressed", String(button.dataset.screen === screen));
    button.disabled = busy || inPractice();
    button.onclick = () => {
      stopSpeech();
      screen = button.dataset.screen;
      message();
      render();
    };
  }
  byId("rename").disabled = busy || inPractice() || !store;
  byId("rename").hidden = Boolean(team);
}

function template(id) {
  view.replaceChildren(byId(id).content.cloneNode(true));
}

function stopSpeech() {
  window.speechSynthesis?.cancel();
}

function speak(text) {
  const synth = window.speechSynthesis;
  const voice = synth?.getVoices().find(v => v.localService && v.lang.toLowerCase().startsWith("ja"));
  if (!voice) return false;
  stopSpeech();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.voice = voice;
  utterance.lang = "ja-JP";
  utterance.rate = 0.91;
  synth.speak(utterance);
  return true;
}

function play(text) {
  if (!speak(text)) message("日本語の端末内音声が使えません。画面の質問・講評を読めます。");
}

function random(pool) {
  return pool[Math.floor(Math.random() * pool.length)];
}

function shuffled(items) {
  const output = [...items];
  for (let i = output.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [output[i], output[j]] = [output[j], output[i]];
  }
  return output;
}

function render() {
  ++historyVersion;
  renderTabs();
  if (screen === "history") { renderHistory(); return; }
  historyView = undefined;
  if (inPractice()) { renderQuestion(); return; }
  if (deck.length) { renderResults(); return; }
  template("setup");
  if (!team) view.querySelector("fieldset").hidden = true;
  byId("start").disabled = busy || !store || !bank.length;
  byId("start").onclick = () => {
    const pool = view.querySelector("input[name=pool]:checked").value === "all" ? bank : bank.filter(q => q.priority);
    const full = view.querySelector("input[name=mode]:checked").value === "full";
    deck = full ? shuffled(criteria.map((_, i) => random(pool.filter(q => q.criterion === i)))) : [random(pool)];
    results = [];
    session = crypto.randomUUID();
    message();
    render();
    play(deck[0].text);
  };
}

function syncControls() {
  const locked = busy || recorder !== null || failureRecord !== null;
  if (byId("answer")) {
    byId("answer").disabled = locked;
    for (const id of ["listen", "grade", "skip", "end"]) byId(id).disabled = busy || recorder !== null;
    byId("record").disabled = busy || failureRecord !== null;
  }
  renderTabs();
}

function renderQuestion() {
  template("question");
  const question = deck[results.length];
  byId("progress").textContent = activeName() + "　・　" + (results.length + 1) + " / " + deck.length + " 問";
  byId("question-text").textContent = question.text;
  byId("listen").onclick = () => play(question.text);
  byId("record").onclick = () => recorder ? recorder.stop() : beginRecording();
  byId("grade").onclick = () => grade(question);
  byId("skip").onclick = () => advance(question, null);
  byId("end").onclick = () => {
    stopSpeech();
    failureRecord = null;
    deck = []; results = [];
    message();
    render();
  };
  syncControls();
}

function modelRequest(kind, input) {
  if (!model) {
    model = new Worker(new URL("./model-worker.js", import.meta.url), { type: "module" });
    model.onmessage = ({ data }) => {
      if (data.status === "loading") {
        message("初回のモデルを準備しています（読み込み " + data.percent + "%）。");
      } else if (modelJob?.id === data.id) {
        clearTimeout(modelJob.timeout);
        if (data.failed) modelJob.reject(new Error(data.issue || "model"));
        else modelJob.resolve(data.result);
        modelJob = null;
      }
    };
    model.onerror = event => {
      if (modelJob) {
        clearTimeout(modelJob.timeout);
        modelJob.reject(new Error(event.message || "worker"));
        modelJob = null;
      }
      model?.terminate();
      model = null;
    };
  }
  return new Promise((resolve, reject) => {
    const id = crypto.randomUUID();
    const timeout = setTimeout(() => {
      model?.terminate();
      model = null;
      modelJob = null;
      reject(new Error("timeout"));
    }, 210000);
    modelJob = { id, timeout, resolve, reject };
    const args = kind === "transcribe" ? { audio: input } : { text: input };
    model.postMessage({ kind, id, ...args }, kind === "transcribe" ? [input.buffer] : []);
  });
}

async function beginRecording() {
  if (!navigator.mediaDevices?.getUserMedia || !window.MediaRecorder || !window.AudioContext) {
    message("この画面ではマイクを使えません。SafariまたはChromeで開くか、回答を入力できます。");
    return;
  }
  stopSpeech();
  message();
  busy = true;
  syncControls();
  let stream;
  try {
    audioContext ||= new AudioContext();
    await audioContext.resume();
    stream = await navigator.mediaDevices.getUserMedia({ audio: { channelCount: 1 }, video: false });
    const current = new MediaRecorder(stream);
    const pieces = [];
    current.ondataavailable = event => { if (event.data.size) pieces.push(event.data); };
    current.onstop = async () => {
      clearTimeout(recordingTimer);
      stream.getTracks().forEach(track => track.stop());
      recorder = null;
      busy = true;
      syncControls();
      message("端末内で文字にしています。");
      try {
        const bytes = await new Blob(pieces, { type: current.mimeType }).arrayBuffer();
        pieces.length = 0;
        const decoded = await audioContext.decodeAudioData(bytes);
        const resampled = new OfflineAudioContext(1, Math.ceil(decoded.duration * 16000), 16000);
        const source = resampled.createBufferSource();
        source.buffer = decoded;
        source.connect(resampled.destination);
        source.start();
        const pcm = (await resampled.startRendering()).getChannelData(0).slice();
        if (pcm.length < 4000 || !pcm.some(value => Math.abs(value) > 0.006)) {
          message("声を聞き取れませんでした。もう一度録ってみてください。");
          return;
        }
        const answer = await modelRequest("transcribe", pcm);
        byId("answer").value = answer.slice(0, 1200);
        message(answer ? "文字起こしを確認して、採点してください。" : "声を聞き取れませんでした。");
      } catch {
        message("文字起こしができませんでした。通信環境を確認して録り直すか、回答を入力できます。");
      } finally {
        busy = false;
        byId("record").textContent = "録り直す";
        syncControls();
      }
    };
    current.onerror = () => { if (current.state !== "inactive") current.stop(); };
    current.start();
    recorder = current;
    recordingTimer = setTimeout(() => { if (recorder === current && current.state === "recording") current.stop(); }, 60000);
    byId("record").textContent = "話し終わった";
    message("録音中。話し終えたらボタンを押してください。");
  } catch {
    stream?.getTracks().forEach(track => track.stop());
    message("マイクを使えませんでした。ブラウザーでマイクを許可するか、回答を入力してください。");
  } finally {
    busy = false;
    syncControls();
  }
}

async function flushQueue() {
  if (!team || !store) return;
  if (flushing) return flushing;
  flushing = (async () => {
    for (const entry of await store.pending(team.queueKey)) {
      await team.send(entry.record);
      await store.sent(entry.attempt.id);
    }
  })();
  try { await flushing; } finally { flushing = null; }
}

async function save(attempt) {
  if (!team) {
    await store.add(attempt);
    return true;
  }
  const record = await team.makeRecord(attempt);
  await store.queue(attempt, record, team.queueKey);
  try {
    await flushQueue();
    return true;
  } catch { return false; }
}

async function grade(question) {
  if (busy) return;
  const answer = byId("answer").value.trim();
  if (!answer) { message("まず、答えてみてください。"); return; }
  stopSpeech();
  busy = true;
  syncControls();
  message("端末内で採点しています。");
  try {
    if (!failureRecord) {
      const vectors = await modelRequest("embedding", inputsFor(question, answer));
      const result = assess(question, answer, vectors);
      failureRecord = { ...result, id: crypto.randomUUID(), session, member: active,
        at: new Date().toISOString(), question: question.text, answer, criterion: criteria[question.criterion] };
    }
    const synced = await save(failureRecord);
    const record = failureRecord;
    failureRecord = null;
    busy = false;
    advance(question, record);
    if (!synced) message("結果は端末に保存しました。通信が戻ると自動で同期します。");
  } catch (error) {
    if (location.hostname === "127.0.0.1") console.warn("Model check:", error.message);
    message(failureRecord ? "記録の保存に失敗しました。「もう一度保存」を押してください。" :
      "採点モデルを準備できませんでした。通信環境を確認し、もう一度お試しください。");
    if (failureRecord) byId("grade").textContent = "もう一度保存";
  } finally {
    busy = false;
    syncControls();
  }
}

function advance(question, record) {
  failureRecord = null;
  results.push({ question, record });
  message();
  render();
  if (inPractice()) play(deck[results.length].text);
  else play(resultText());
}

function sum() {
  return results.length === 6 && results.every(row => row.record) ?
    results.reduce((total, row) => total + row.record.score, 0) : null;
}

function resultText() {
  const lines = results.map(({ question, record }) => criteria[question.criterion] + (record ? "は" + record.score + "点。" : "は未評価です。"));
  const total = sum();
  if (total !== null) lines.push("合計は60点満点で" + total + "点です。");
  const records = results.flatMap(row => row.record ? [row.record] : []).sort((a, b) => b.score - a.score);
  if (records[0]?.good) lines.push(records[0].good);
  if (records.length) lines.push(records.at(-1).next);
  return lines.join(" ");
}

function resultCard(record, showAnswer, timeline = false) {
  const article = document.createElement("article");
  article.className = "record";
  const title = document.createElement("h3");
  const score = document.createElement("span");
  score.className = "score-tile";
  score.textContent = record.score === null ? "未評価" : record.score + " / 10";
  title.append(record.criterion + " ", score);
  if (timeline) {
    const meta = document.createElement("div");
    meta.className = "record-meta";
    const name = document.createElement("strong");
    name.textContent = memberName(record.member);
    const time = document.createElement("time");
    time.dateTime = record.at;
    time.textContent = new Date(record.at).toLocaleString("ja-JP", {
      dateStyle: "medium", timeStyle: "short", timeZone: "Asia/Tokyo",
    });
    meta.append(name, time);
    article.append(meta);
  }
  article.append(title);
  const details = document.createElement("dl");
  const rows = [["問題", record.question]];
  if (showAnswer) rows.push(["回答", record.answer]);
  if (record.at && !timeline) rows.push(["練習日", new Date(record.at).toLocaleString("ja-JP", { dateStyle: "medium", timeStyle: "short" })]);
  if (record.next) rows.push(["講評", [record.good, record.next].filter(Boolean).join("\n")]);
  for (const [label, value] of rows) {
    const dt = document.createElement("dt");
    const dd = document.createElement("dd");
    dt.textContent = label; dd.textContent = value;
    details.append(dt, dd);
  }
  article.append(details);
  return article;
}

function renderResults() {
  template("results");
  const total = sum();
  byId("total").textContent = total !== null ? "合計 " + total + " / 60" :
    results.length === 6 ? "未評価の項目があります" : "質疑応答の練習点";
  byId("scores").append(...results.map(({ question, record }) => resultCard(record || {
    question: question.text, criterion: criteria[question.criterion], score: null,
  }, false)));
  byId("read-results").onclick = () => play(resultText());
  byId("restart").onclick = () => {
    stopSpeech();
    deck = []; results = [];
    message();
    render();
  };
}

async function renderHistory() {
  const revision = historyVersion;
  const id = team ? historyMember : active;
  const isCurrent = () => revision === historyVersion && screen === "history";
  if (!historyView || historyView.id !== id) {
    const title = document.createElement("h2");
    title.textContent = id === null ? "みんなの練習タイムライン" : memberName(id) + " の挑戦の記録";
    const list = document.createElement("div");
    if (team) list.className = "timeline";
    list.textContent = "記録を読み込んでいます。";
    historyView = { id, list, recordIds: null };
    view.replaceChildren(title, list);
  }
  const panel = historyView;
  try {
    if (!store) return;
    let records;
    if (team) {
      const slots = id === null ? names.map(member => member.id) : [id];
      try { await flushQueue(); } catch { /* retry on the next connection */ }
      const pending = (await store.pending(team.queueKey)).map(row => row.attempt)
        .filter(row => slots.includes(row.member));
      let online;
      try { online = (await Promise.all(slots.map(slot => team.attempts(slot)))).flat(); }
      catch {
        if (isCurrent()) message("同期先につながりません。通信が戻ると自動で更新します。");
        if (panel.recordIds !== null) return;
        online = [];
      }
      records = Array.from(new Map([...online, ...pending].map(row => [row.id, row])).values());
    } else records = (await store.attempts()).filter(row => row.member === id);
    if (!isCurrent()) return;
    records.sort((a, b) => b.at.localeCompare(a.at) || a.id.localeCompare(b.id));
    const recordIds = records.map(row => row.id).join(",");
    if (panel.recordIds === recordIds) return;
    panel.recordIds = recordIds;
    panel.list.replaceChildren(...records.map(row => resultCard(row, true, Boolean(team))));
    if (!records.length) panel.list.textContent = "まだ練習の記録はありません。";
  } catch {
    if (isCurrent()) message("記録を読み込めませんでした。");
  }
}

byId("rename").onclick = () => {
  byId("name").value = activeName();
  byId("name-dialog").returnValue = "";
  byId("name-dialog").showModal();
};
byId("name-dialog").onclose = async () => {
  const name = byId("name").value.trim();
  if (byId("name-dialog").returnValue !== "save" || !name) return;
  try {
    await store.rename(active, name);
    names.find(member => member.id === active).name = name;
    render();
  } catch { message("名前を保存できませんでした。"); }
};
async function backgroundSync() {
  if (!team || busy) return;
  try { await flushQueue(); } catch { /* saved on the device; retry on focus or connection */ }
  if (screen === "history") { ++historyVersion; await renderHistory(); }
}
window.addEventListener("online", backgroundSync);
window.addEventListener("focus", backgroundSync);
document.addEventListener("visibilitychange", () => { if (!document.hidden) backgroundSync(); });
setInterval(() => { if (!document.hidden) backgroundSync(); }, 15000);
window.speechSynthesis?.getVoices();

try {
  const questions = fetch("./questions.json").then(response => response.json());
  store = await openHistory();
  try { team = await connectTeam(); }
  catch {
    message("専用リンクを確認できませんでした。リンクを開き直してください。");
  }
  if (team) {
    names = team.profiles;
    active = team.slot ?? names[0].id;
    screen = team.role === "owner" ? "history" : "practice";
    const info = byId("team-status");
    info.hidden = false;
    info.textContent = "記録はチーム内で共有";
    const out = document.createElement("button");
    out.type = "button"; out.className = "quiet"; out.textContent = "チームから退出";
    out.onclick = () => { leaveTeam(); location.reload(); };
    info.append(" ", out);
    backgroundSync();
  } else {
    for (const member of await store.names()) {
      const existing = names.find(entry => entry.id === member.id);
      if (existing) existing.name = member.name;
    }
  }
  const incoming = team ? await team.questions() : await questions;
  const expected = team ? 156 : 6;
  if (incoming.length === expected && incoming.filter(q => q.priority).length === (team ? 20 : 6) &&
      criteria.every((_, i) => incoming.some(q => q.priority && q.criterion === i))) bank = incoming;
  render();
  if (bank.length !== expected) message("質問集を開けませんでした。ページを読み込み直してください。");
} catch {
  render();
  message("練習の準備ができませんでした。SafariまたはChromeの通常のタブで開いてください。");
}
