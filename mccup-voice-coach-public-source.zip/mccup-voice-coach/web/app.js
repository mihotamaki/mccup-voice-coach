import { openHistory } from "./history.js";
import { assess, criteria, inputsFor, spokenReasons, spokenTips } from "./rubric.js";
import { connectTeam, leaveTeam } from "./sync.js";
import { createVoicePlayer, publicClip, setAudioSession } from "./voice.js";

const voicePlayer = createVoicePlayer();
const practiceConcepts = fetch("./practice-concepts.json", { cache: "no-store" })
  .then(response => response.ok ? response.json() : [])
  .then(groups => Array.isArray(groups) ? groups.filter(group =>
    Array.isArray(group) && group.every(terms => Array.isArray(terms) && terms.length &&
      terms.every(term => typeof term === "string" && term.trim()))) : [])
  .catch(() => []);
let speechRequest = 0;

const byId = id => document.getElementById(id);
const view = byId("view");
let names = Array.from({ length: 7 }, (_, id) => ({ id, name: "メンバー " + (id + 1) }));
let active = 0;
let screen = "practice";
let bank = [];
let store;
let team;
let canRename = false;
let deck = [];
let results = [];
let drill = null;
let session;
let busy = false;
let recorder = null;
let recordingTimer;
let audioContext;
let model;
let modelJob;
let failureRecord = null;
let historyVersion = 0;
let historyMember = null;
let historyView;
let flushing;

const memberName = id => names.find(member => member.id === id)?.name || "メンバー";
const activeName = () => memberName(active);
const inPractice = () => deck.length > results.length;

function message(value = "") {
  byId("status").textContent = value;
  byId("status").hidden = !value;
}

function renderTabs() {
  const locked = busy || Boolean(drill) || inPractice();
  const filtering = Boolean(team) && screen === "history";
  const options = filtering ? [{ id: null, name: "みんな" }, ...names] :
    team?.role === "member" ? names.filter(member => member.id === team.slot) : names;
  const buttons = options.map(member => {
    const button = document.createElement("button");
    button.type = "button";
    button.textContent = member.name;
    button.setAttribute("aria-pressed", String((filtering ? historyMember : active) === member.id));
    button.disabled = locked;
    button.onclick = () => {
      stopSpeech();
      if (filtering) historyMember = member.id;
      else {
        active = member.id;
        deck = []; results = [];
      }
      message();
      render();
    };
    return button;
  });
  const members = byId("members");
  members.setAttribute("aria-label", filtering ? "履歴を絞り込む" : "練習するメンバー");
  members.replaceChildren(...buttons);
  for (const button of document.querySelectorAll("[data-screen]")) {
    button.setAttribute("aria-pressed", String(button.dataset.screen === screen));
    button.disabled = locked;
    button.onclick = () => {
      stopSpeech();
      screen = button.dataset.screen;
      message();
      render();
    };
  }
  byId("rename").disabled = locked || !canRename;
  byId("rename").hidden = !canRename;
}

function template(id) {
  view.replaceChildren(byId(id).content.cloneNode(true));
}

function stopSpeech() {
  speechRequest++;
  voicePlayer.stop();
  window.speechSynthesis?.cancel();
}

function speak(text) {
  const synth = window.speechSynthesis;
  const voice = synth?.getVoices().find(v => v.localService && v.lang.toLowerCase().startsWith("ja"));
  if (!voice) return false;
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.voice = voice;
  utterance.lang = "ja-JP";
  utterance.rate = 0.91;
  synth.speak(utterance);
  return true;
}

function playClips(clips, fallback, retryLabel) {
  window.speechSynthesis?.cancel();
  const audio = byId("voice-audio");
  if (!audio) return;
  const request = ++speechRequest;
  Promise.resolve(voicePlayer.play(audio, clips)).catch(() => {
    if (speechRequest !== request) return;
    if (!audio.hidden) message("自動で音が出ないときは、音声バーの ▶ を押してください。");
    else if (!speak(fallback)) message("音声を準備できませんでした。「" + retryLabel + "」を押してください。");
  });
}

function connectVoiceControls() {
  const audio = byId("voice-audio");
  audio.onplay = () => {
    setAudioSession("playback");
    if (byId("status").textContent.startsWith("自動で音が出ない")) message();
  };
  audio.onended = () => {
    if (byId("voice-audio") === audio && audio.ended) setAudioSession("auto");
  };
}

function playQuestion(question) {
  const clip = team ? { id: "team-" + question.id, load: () => team.questionAudio(question.id) }
    : publicClip("public-" + question.id);
  playClips([clip], question.text, "もう一度聞く");
}

function playResults() {
  const clips = [];
  const lines = [];
  const say = (id, line) => {
    clips.push(publicClip(id));
    lines.push(line);
  };
  say("beginning", "練習の結果です。");
  const hasRatings = results.some(row => row.record);
  if (!hasRatings) say("all-skipped", "評価できる回答がありませんでした。");
  else for (const { question, record } of results) {
    say("criterion-" + question.criterion, criteria[question.criterion]);
    if (!record) {
      say("skipped", "は未評価です。");
      continue;
    }
    const { rating, score100, next } = record;
    say("stars-" + rating.stars, "は、星5つのうち" + rating.stars + "です。");
    say("reason-" + spokenReasons.indexOf(rating.reason), rating.reason);
    if (record.conceptBonus?.points > 0) {
      say("concept-bonus", "コンセプトマップの加点");
      say("score-" + record.conceptBonus.points, "は" + record.conceptBonus.points + "点です。");
    } else if (record.conceptBonus) {
      say("concept-match", "コンセプトマップのことばも使えました。");
    }
    say("question-score", "この質問の練習点");
    say("score-" + score100, "は" + score100 + "点です。");
    say("tip-" + spokenTips.indexOf(next), next);
  }
  playClips(clips, lines.join(" "), "結果をもう一度聞く");
}

function random(pool) {
  return pool[Math.floor(Math.random() * pool.length)];
}

function shuffled(items) {
  const output = [...items];
  for (let i = output.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [output[i], output[j]] = [output[j], output[i]];
  }
  return output;
}


function nextDrillQuestion() {
  stopSpeech();
  if (!drill.remaining.length) {
    drill.remaining = shuffled(drill.pool);
    if (drill.remaining.length > 1 && drill.remaining.at(-1).id === deck[0]?.id) {
      drill.remaining.unshift(drill.remaining.pop());
    }
  }
  deck = [drill.remaining.pop()];
  results = [];
  failureRecord = null;
  drill.number++;
  message();
  render();
  byId("question-text").focus();
  playQuestion(deck[0]);
}

function finishPractice() {
  stopSpeech();
  const endedDrill = Boolean(drill);
  drill = null;
  failureRecord = null;
  deck = [];
  results = [];
  message(endedDrill ? "壁打ちを終了しました。採点した回答は「挑戦の記録」で見られます。" : "");
  render();
  if (endedDrill) byId("start").focus();
}

function render() {
  ++historyVersion;
  renderTabs();
  if (screen === "history") { renderHistory(); return; }
  historyView = undefined;
  if (inPractice()) { renderQuestion(); return; }
  if (deck.length) { renderResults(); return; }
  template("setup");
  if (!team) view.querySelector("fieldset").hidden = true;
  byId("start").disabled = busy || !store || !bank.length;
  byId("start").onclick = () => {
    const pool = view.querySelector("input[name=pool]:checked").value === "all" ? bank : bank.filter(q => q.priority);
    const mode = view.querySelector("input[name=mode]:checked").value;
    session = crypto.randomUUID();
    if (mode === "drill") {
      drill = { pool, remaining: [], number: 0 };
      nextDrillQuestion();
      return;
    }
    deck = mode === "full" ? shuffled(criteria.map((_, i) => random(pool.filter(q => q.criterion === i)))) : [random(pool)];
    results = [];
    message();
    render();
    playQuestion(deck[0]);
  };
}

function syncControls() {
  const locked = busy || recorder !== null || failureRecord !== null;
  if (byId("answer")) {
    byId("answer").disabled = locked;
    for (const id of ["listen", "grade", "skip", "end"]) byId(id).disabled = busy || recorder !== null;
    byId("record").disabled = busy || failureRecord !== null;
  }
  renderTabs();
}

function renderQuestion() {
  template("question");
  const question = deck[results.length];
  const progress = drill ? "壁打ち " + drill.number + "問目" : (results.length + 1) + " / " + deck.length + " 問";
  byId("progress").textContent = activeName() + "　・　" + progress;
  byId("question-text").textContent = question.text;
  connectVoiceControls();
  byId("listen").onclick = () => playQuestion(question);
  byId("record").onclick = () => recorder ? recorder.stop() : beginRecording();
  byId("grade").onclick = () => grade(question);
  byId("skip").onclick = drill ? nextDrillQuestion : () => advance(question, null);
  if (drill) byId("end").textContent = "壁打ちを終える";
  byId("end").onclick = finishPractice;
  syncControls();
}

function modelRequest(kind, input) {
  if (!model) {
    model = new Worker(new URL("./model-worker.js", import.meta.url), { type: "module" });
    model.onmessage = ({ data }) => {
      if (data.status === "loading") {
        message("初回のモデルを準備しています（読み込み " + data.percent + "%）。");
      } else if (modelJob?.id === data.id) {
        clearTimeout(modelJob.timeout);
        if (data.failed) modelJob.reject(new Error(data.issue || "model"));
        else modelJob.resolve(data.result);
        modelJob = null;
      }
    };
    model.onerror = event => {
      if (modelJob) {
        clearTimeout(modelJob.timeout);
        modelJob.reject(new Error(event.message || "worker"));
        modelJob = null;
      }
      model?.terminate();
      model = null;
    };
  }
  return new Promise((resolve, reject) => {
    const id = crypto.randomUUID();
    const timeout = setTimeout(() => {
      model?.terminate();
      model = null;
      modelJob = null;
      reject(new Error("timeout"));
    }, 210000);
    modelJob = { id, timeout, resolve, reject };
    const args = kind === "transcribe" ? { audio: input } : { text: input };
    model.postMessage({ kind, id, ...args }, kind === "transcribe" ? [input.buffer] : []);
  });
}

async function beginRecording() {
  if (!navigator.mediaDevices?.getUserMedia || !window.MediaRecorder || !window.AudioContext) {
    message("この画面ではマイクを使えません。SafariまたはChromeで開くか、回答を入力できます。");
    return;
  }
  stopSpeech();
  setAudioSession("auto");
  message();
  busy = true;
  syncControls();
  let stream;
  try {
    audioContext ||= new AudioContext();
    await audioContext.resume();
    stream = await navigator.mediaDevices.getUserMedia({ audio: { channelCount: 1 }, video: false });
    const current = new MediaRecorder(stream);
    const pieces = [];
    current.ondataavailable = event => { if (event.data.size) pieces.push(event.data); };
    current.onstop = async () => {
      clearTimeout(recordingTimer);
      stream.getTracks().forEach(track => track.stop());
      recorder = null;
      busy = true;
      syncControls();
      message("端末内で文字にしています。");
      try {
        const bytes = await new Blob(pieces, { type: current.mimeType }).arrayBuffer();
        pieces.length = 0;
        const decoded = await audioContext.decodeAudioData(bytes);
        const resampled = new OfflineAudioContext(1, Math.ceil(decoded.duration * 16000), 16000);
        const source = resampled.createBufferSource();
        source.buffer = decoded;
        source.connect(resampled.destination);
        source.start();
        const pcm = (await resampled.startRendering()).getChannelData(0).slice();
        if (pcm.length < 4000 || !pcm.some(value => Math.abs(value) > 0.006)) {
          message("声を聞き取れませんでした。もう一度録ってみてください。");
          return;
        }
        const answer = await modelRequest("transcribe", pcm);
        byId("answer").value = answer.slice(0, 1200);
        message(answer ? "文字起こしを確認して、採点してください。" : "声を聞き取れませんでした。");
      } catch {
        message("文字起こしができませんでした。通信環境を確認して録り直すか、回答を入力できます。");
      } finally {
        busy = false;
        byId("record").textContent = "録り直す";
        syncControls();
      }
    };
    current.onerror = () => { if (current.state !== "inactive") current.stop(); };
    current.start();
    recorder = current;
    recordingTimer = setTimeout(() => { if (recorder === current && current.state === "recording") current.stop(); }, 60000);
    byId("record").textContent = "話し終わった";
    message("録音中。話し終えたらボタンを押してください。");
  } catch {
    stream?.getTracks().forEach(track => track.stop());
    message("マイクを使えませんでした。ブラウザーでマイクを許可するか、回答を入力してください。");
  } finally {
    busy = false;
    syncControls();
  }
}

async function flushQueue() {
  if (!team || !store) return;
  if (flushing) return flushing;
  flushing = (async () => {
    for (const entry of await store.pending(team.queueKey)) {
      await team.send(entry.record);
      await store.sent(entry.attempt.id);
    }
  })();
  try { await flushing; } finally { flushing = null; }
}

async function save(attempt) {
  if (!team) {
    await store.add(attempt);
    return true;
  }
  const record = await team.makeRecord(attempt);
  await store.queue(attempt, record, team.queueKey);
  try {
    await flushQueue();
    return true;
  } catch { return false; }
}

async function grade(question) {
  if (busy) return;
  const answer = byId("answer").value.trim();
  if (!answer) { message("まず、答えてみてください。"); return; }
  stopSpeech();
  busy = true;
  syncControls();
  message("端末内で採点しています。");
  try {
    if (!failureRecord) {
      const vectors = await modelRequest("embedding", inputsFor(question, answer));
      const result = assess(question, answer, vectors, await practiceConcepts);
      failureRecord = { ...result, id: crypto.randomUUID(), session, member: active,
        at: new Date().toISOString(), question: question.text, answer, criterion: criteria[question.criterion] };
    }
    const synced = await save(failureRecord);
    const record = failureRecord;
    failureRecord = null;
    busy = false;
    advance(question, record);
    if (!synced) message("結果は端末に保存しました。通信が戻ると自動で同期します。");
  } catch (error) {
    if (location.hostname === "127.0.0.1") console.warn("Model check:", error.message);
    message(failureRecord ? "記録の保存に失敗しました。「もう一度保存」を押してください。" :
      "採点モデルを準備できませんでした。通信環境を確認し、もう一度お試しください。");
    if (failureRecord) byId("grade").textContent = "もう一度保存";
  } finally {
    busy = false;
    syncControls();
  }
}

function advance(question, record) {
  failureRecord = null;
  results.push({ question, record });
  message();
  render();
  if (inPractice()) playQuestion(deck[results.length]);
  else playResults();
}

function assessmentList(ratings) {
  const list = document.createElement("ul");
  list.className = "assessment";
  for (const [criterion, rating] of ratings) {
    if (!rating) continue;
    const item = document.createElement("li");
    const header = document.createElement("div");
    const name = document.createElement("strong");
    name.textContent = criterion;
    const stars = document.createElement("span");
    stars.className = "assessment-stars";
    stars.setAttribute("role", "img");
    stars.setAttribute("aria-label", "星5つのうち" + rating.stars);
    const empty = document.createElement("span");
    empty.textContent = "☆".repeat(5 - rating.stars);
    stars.append("★".repeat(rating.stars), empty);
    header.append(name, stars);
    const reason = document.createElement("p");
    reason.textContent = rating.reason;
    item.append(header, reason);
    list.append(item);
  }
  return list;
}

function scoreLabel(record) {
  if (Number.isInteger(record.score100)) return record.score100 + " / 100";
  if (Number.isInteger(record.overall)) return record.overall + " / 100（旧）";
  return record.score == null ? "未評価" : record.score + " / 10（旧）";
}

function resultCard(record, timeline = false) {
  const article = document.createElement("article");
  article.className = "record";
  const title = document.createElement("h3");
  const score = document.createElement("span");
  score.className = "score-tile";
  score.textContent = scoreLabel(record);
  title.textContent = record.criterion + " の質問";
  if (!record.rating && !record.assessment) title.append(score);
  if (timeline) {
    const meta = document.createElement("div");
    meta.className = "record-meta";
    const name = document.createElement("strong");
    name.textContent = memberName(record.member);
    const time = document.createElement("time");
    time.dateTime = record.at;
    time.textContent = new Date(record.at).toLocaleString("ja-JP", {
      dateStyle: "medium", timeStyle: "short", timeZone: "Asia/Tokyo",
    });
    meta.append(name, time);
    article.append(meta);
  }
  article.append(title);
  const details = document.createElement("dl");
  const rows = [["問題", record.question]];
  if (record.answer) rows.push(["回答", record.answer]);
  if (record.at && !timeline) rows.push(["練習日", new Date(record.at).toLocaleString("ja-JP", { dateStyle: "medium", timeStyle: "short" })]);

  for (const [label, value] of rows) {
    const dt = document.createElement("dt");
    const dd = document.createElement("dd");
    dt.textContent = label; dd.textContent = value;
    details.append(dt, dd);
  }
  article.append(details);
  if (record.rating || record.assessment) {
    const ratings = record.rating ? [[record.criterion, record.rating]]
      : record.assessment.map((rating, index) => [criteria[index], rating]);
    const points = document.createElement("p");
    points.className = "record-total";
    points.append(record.rating ? "この質問の練習点 " : "6観点の総合点 ", score);
    article.append(assessmentList(ratings));
    if (record.conceptBonus) {
      const bonus = document.createElement("p");
      bonus.className = "concept-bonus";
      const { terms, points: bonusPoints } = record.conceptBonus;
      const label = bonusPoints ? "コンセプトマップ +" + bonusPoints + "点" : "コンセプトマップのことば（100点上限）";
      bonus.textContent = label + "　" + terms.join("・");
      article.append(bonus);
    }
    article.append(points);
  }
  if (record.next) {
    const comment = document.createElement("div");
    comment.className = "evaluation-comment";
    const label = document.createElement("strong");
    label.textContent = "講評";
    const body = document.createElement("p");
    body.textContent = [record.good, record.next].filter(Boolean).join("\n");
    comment.append(label, body);
    article.append(comment);
  }
  return article;
}

function renderResults() {
  template("results");
  byId("assessment-note").hidden = !results.some(row => row.record);
  byId("scores").append(...results.map(({ question, record }) => resultCard(record || {
    question: question.text, criterion: criteria[question.criterion], score: null,
  })));
  connectVoiceControls();
  byId("read-results").onclick = playResults;
  const finish = byId("restart");
  finish.onclick = finishPractice;
  if (drill) {
    byId("result-title").textContent = "壁打ち " + drill.number + "問目の結果";
    const next = byId("next-question");
    next.hidden = false;
    next.onclick = nextDrillQuestion;
    finish.textContent = "壁打ちを終える";
    finish.className = "quiet";
  }
}

function teamScoreboard() {
  const section = document.createElement("section");
  section.className = "team-scoreboard";
  const heading = document.createElement("h2");
  heading.textContent = "チームの最新成績";
  const grid = document.createElement("ul");
  grid.className = "team-score-grid";
  section.append(heading, grid);
  return { section, grid };
}

function showTeamScores(grid, records, missing) {
  const latest = new Map();
  for (const record of records) {
    const current = latest.get(record.member);
    if (!current || record.at > current.at || (record.at === current.at && record.id < current.id)) {
      latest.set(record.member, record);
    }
  }
  grid.replaceChildren(...names.map(member => {
    const item = document.createElement("li");
    const name = document.createElement("strong");
    name.textContent = member.name;
    const score = document.createElement("span");
    const detail = document.createElement("small");
    const record = latest.get(member.id);
    if (record) {
      score.className = "score-tile";
      score.textContent = scoreLabel(record);
      detail.textContent = record.criterion;
    } else {
      score.className = "score-empty";
      score.textContent = missing;
    }
    item.append(name, score, detail);
    return item;
  }));
}

async function renderHistory() {
  const revision = historyVersion;
  const id = team ? historyMember : active;
  const isCurrent = () => revision === historyVersion && screen === "history";
  if (!historyView || historyView.id !== id) {
    const title = document.createElement("h2");
    title.textContent = id === null ? "みんなの練習タイムライン（" + names.length + "人）" : memberName(id) + " の挑戦の記録";
    const list = document.createElement("div");
    if (team) list.className = "timeline";
    list.textContent = "記録を読み込んでいます。";
    const scoreboard = team ? teamScoreboard() : null;
    historyView = { id, list, recordIds: null, scoreboard, scoreIds: null };
    if (scoreboard) {
      showTeamScores(scoreboard.grid, [], "読み込み中");
      view.replaceChildren(scoreboard.section, title, list);
    } else view.replaceChildren(title, list);
  }
  const panel = historyView;
  try {
    if (!store) return;
    let records;
    if (team) {
      const slots = names.map(member => member.id);
      try { await flushQueue(); } catch { /* retry on the next connection */ }
      const pending = (await store.pending(team.queueKey)).map(row => row.attempt);
      let online;
      try { online = (await Promise.all(slots.map(slot => team.attempts(slot)))).flat(); }
      catch {
        if (isCurrent()) message("同期先につながりません。通信が戻ると自動で更新します。");
      }
      if (!isCurrent()) return;
      if (online) {
        const scoreIds = online.map(row => row.id).sort().join(",");
        if (panel.scoreIds !== scoreIds) {
          showTeamScores(panel.scoreboard.grid, online, "まだ記録なし");
          panel.scoreIds = scoreIds;
        }
      } else if (panel.scoreIds === null) {
        showTeamScores(panel.scoreboard.grid, [], "同期待ち");
      }
      if (!online && panel.recordIds !== null) return;
      records = Array.from(new Map([...(online ?? []), ...pending].map(row => [row.id, row])).values())
        .filter(row => id === null || row.member === id);
    } else records = (await store.attempts()).filter(row => row.member === id);
    if (!isCurrent()) return;
    records.sort((a, b) => b.at.localeCompare(a.at) || a.id.localeCompare(b.id));
    const recordIds = records.map(row => row.id).join(",");
    if (panel.recordIds === recordIds) return;
    panel.recordIds = recordIds;
    panel.list.replaceChildren(...records.map(row => resultCard(row, Boolean(team))));
    if (!records.length) panel.list.textContent = "まだ練習の記録はありません。";
  } catch {
    if (isCurrent()) message("記録を読み込めませんでした。");
  }
}

byId("rename").onclick = () => {
  byId("name").value = activeName();
  byId("name-dialog").returnValue = "";
  byId("name-dialog").showModal();
};
byId("name-dialog").onclose = async () => {
  const name = byId("name").value.trim();
  if (byId("name-dialog").returnValue !== "save" || !name) return;
  try {
    await store.rename(active, name);
    names.find(member => member.id === active).name = name;
    render();
  } catch { message("名前を保存できませんでした。"); }
};
async function backgroundSync() {
  if (!team || busy) return;
  try { await flushQueue(); } catch { /* saved on the device; retry on focus or connection */ }
  if (screen === "history") { ++historyVersion; await renderHistory(); }
}
window.addEventListener("online", backgroundSync);
window.addEventListener("focus", backgroundSync);
document.addEventListener("visibilitychange", () => { if (!document.hidden) backgroundSync(); });
setInterval(() => { if (!document.hidden) backgroundSync(); }, 15000);
window.speechSynthesis?.getVoices();

try {
  const questions = fetch("./questions.json").then(response => response.json());
  try { team = await connectTeam(); }
  catch {
    message("専用リンクを確認できませんでした。リンクを開き直してください。");
  }
  let historyEpoch = team?.historyEpoch;
  if (!team) {
    const response = await fetch("./history-epoch.json", { cache: "no-store" });
    if (!response.ok) throw new Error("history");
    historyEpoch = await response.json();
  }
  store = await openHistory(historyEpoch);
  if (team) {
    names = team.profiles;
    active = team.slot ?? names[0].id;
    screen = team.role === "owner" ? "history" : "practice";
    const info = byId("team-status");
    info.textContent = "チーム版・" + names.length + "人";
    const out = document.createElement("button");
    out.type = "button"; out.className = "quiet"; out.textContent = "チームから退出";
    out.onclick = () => { leaveTeam(); location.reload(); };
    info.append(" ", out);
    backgroundSync();
  } else {
    try {
      const response = await fetch("./public-members.json", { cache: "no-store" });
      if (!response.ok) throw new Error("roster");
      const commonNames = await response.json();
      if (commonNames === null) {
        for (const member of await store.names()) {
          const existing = names.find(entry => entry.id === member.id);
          if (existing) existing.name = member.name;
        }
        canRename = true;
      } else {
        names = commonNames.map((name, id) => ({ id, name }));
      }
    } catch {
      message("共通の名前を読み込めませんでした。ページを開き直してください。");
    }
  }
  const incoming = team ? await team.questions() : await questions;
  const expected = team ? 156 : 6;
  if (incoming.length === expected && incoming.filter(q => q.priority).length === (team ? 20 : 6) &&
      criteria.every((_, i) => incoming.some(q => q.priority && q.criterion === i))) bank = incoming;
  render();
  if (bank.length !== expected) message("質問集を開けませんでした。ページを読み込み直してください。");
} catch {
  render();
  message("練習の準備ができませんでした。SafariまたはChromeの通常のタブで開いてください。");
}
