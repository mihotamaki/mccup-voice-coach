export function setAudioSession(type) {
  try {
    if (navigator.audioSession) navigator.audioSession.type = type;
  } catch {
    // Older browsers use their normal media routing.
  }
}

async function resultWave(clips) {
  const Decoder = window.OfflineAudioContext || window.webkitOfflineAudioContext;
  if (!Decoder) throw new Error("audio");
  const rate = 16000;
  const decoder = new Decoder(1, 1, rate);
  const samples = await Promise.all(clips.map(async clip => {
    const audio = await decoder.decodeAudioData(await clip.load());
    return audio.getChannelData(0);
  }));
  const pause = Math.round(rate * .05);
  const size = samples.reduce((total, block) => total + (block.length + pause) * 2, 0);
  const wave = new DataView(new ArrayBuffer(44 + size));
  const label = (offset, text) => {
    for (const char of text) wave.setUint8(offset++, char.charCodeAt(0));
  };
  label(0, "RIFF");
  wave.setUint32(4, 36 + size, true);
  label(8, "WAVEfmt ");
  wave.setUint32(16, 16, true);
  wave.setUint16(20, 1, true); // PCM
  wave.setUint16(22, 1, true); // mono
  wave.setUint32(24, rate, true);
  wave.setUint32(28, rate * 2, true);
  wave.setUint16(32, 2, true);
  wave.setUint16(34, 16, true);
  label(36, "data");
  wave.setUint32(40, size, true);
  let offset = 44;
  for (const block of samples) {
    for (const sample of block) {
      wave.setInt16(offset, Math.round(Math.max(-1, Math.min(1, sample)) * 32767), true);
      offset += 2;
    }
    offset += pause * 2;
  }
  return new Blob([wave.buffer], { type: "audio/wav" });
}

export function createVoicePlayer() {
  let active;

  function stop() {
    if (!active) return;
    const { audio, url } = active;
    active = undefined;
    audio.pause();
    audio.hidden = true;
    audio.removeAttribute("src");
    audio.load();
    if (url) URL.revokeObjectURL(url);
    setAudioSession("auto");
  }

  function play(audio, clips) {
    const id = clips.map(clip => clip.id).join("|");
    if (active?.audio !== audio || active.id !== id) {
      stop();
      const current = { audio, id };
      active = current;
      if (clips.length === 1 && clips[0].url) {
        audio.src = clips[0].url;
        audio.hidden = false;
      } else {
        current.ready = (clips.length === 1
          ? clips[0].load().then(bytes => new Blob([bytes], { type: "audio/mpeg" }))
          : resultWave(clips)).then(blob => {
          if (active !== current) return;
          current.url = URL.createObjectURL(blob);
          audio.src = current.url;
          audio.hidden = false;
        }).catch(error => {
          if (active === current) stop();
          throw error;
        });
      }
    }

    const current = active;
    setAudioSession("playback");
    const start = () => {
      if (active !== current) return;
      setAudioSession("playback");
      if (audio.currentTime) audio.currentTime = 0;
      return audio.play();
    };
    // A replay with a loaded source reaches play() in the same tap.
    return audio.hasAttribute("src") ? start() : current.ready.then(start);
  }

  return { play, stop };
}

export function publicClip(name) {
  const url = "./voice-" + name + ".mp3";
  return {
    id: name,
    url,
    async load() {
      const response = await fetch(url);
      if (!response.ok) throw new Error("audio");
      return response.arrayBuffer();
    },
  };
}
