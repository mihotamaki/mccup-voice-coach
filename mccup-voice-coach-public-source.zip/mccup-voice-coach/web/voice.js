export function createVoicePlayer() {
  let context;
  let active;
  let generation = 0;
  const decoded = new Map();

  function stop() {
    generation++;
    if (active) {
      active.stop();
      active = undefined;
    }
  }

  async function play(clips) {
    stop();
    const current = generation;
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    if (!AudioContext) throw new Error("audio");
    context ||= new AudioContext();
    // Resume immediately inside the tap handler, before fetching or decoding.
    if (context.state !== "running") {
      const resume = context.resume();
      await new Promise((resolve, reject) => {
        const deadline = setTimeout(() => reject(new Error("gesture")), 1600);
        resume.then(value => { clearTimeout(deadline); resolve(value); },
                    error => { clearTimeout(deadline); reject(error); });
      });
    }
    const buffers = await Promise.all(clips.map(async clip => {
      if (!decoded.has(clip.id)) {
        const item = clip.load().then(bytes => context.decodeAudioData(bytes));
        decoded.set(clip.id, item);
        item.catch(() => { if (decoded.get(clip.id) === item) decoded.delete(clip.id); });
        if (decoded.size > 40) decoded.delete(decoded.keys().next().value);
      }
      return decoded.get(clip.id);
    }));
    if (generation !== current || !buffers.length) return;
    // One buffer keeps the whole result in a single playback, even on mobile.
    const sampleRate = context.sampleRate;
    const silence = Math.round(sampleRate * .05);
    const output = context.createBuffer(1, buffers.reduce((n, buffer) => n + buffer.length + silence, 0), sampleRate);
    const channel = output.getChannelData(0);
    let offset = 0;
    for (const buffer of buffers) {
      channel.set(buffer.getChannelData(0), offset);
      offset += buffer.length + silence;
    }
    const source = context.createBufferSource();
    source.buffer = output;
    source.connect(context.destination);
    active = source;
    source.onended = () => { if (active === source) active = undefined; };
    source.start();
  }

  return { play, stop };
}

export function publicClip(name) {
  return {
    id: name,
    async load() {
      const response = await fetch("./voice-" + name + ".mp3");
      if (!response.ok) throw new Error("audio");
      return response.arrayBuffer();
    },
  };
}
