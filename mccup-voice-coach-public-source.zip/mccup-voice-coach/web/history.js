function requestValue(request) {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

function finished(transaction) {
  return new Promise((resolve, reject) => {
    transaction.oncomplete = () => resolve();
    transaction.onabort = transaction.onerror = () => reject(transaction.error);
  });
}

export async function openHistory() {
  const request = indexedDB.open("mccup-voice-coach-v2", 2);
  request.onupgradeneeded = () => {
    for (const name of ["secrets", "names", "attempts", "outbox"]) {
      if (!request.result.objectStoreNames.contains(name)) request.result.createObjectStore(name);
    }
  };
  const database = await requestValue(request);
  let key = await requestValue(database.transaction("secrets").objectStore("secrets").get("local"));
  if (!key) {
    const candidate = await crypto.subtle.generateKey({ name: "AES-GCM", length: 256 }, false, ["encrypt", "decrypt"]);
    const transaction = database.transaction("secrets", "readwrite");
    const store = transaction.objectStore("secrets");
    const existing = await requestValue(store.get("local"));
    key = existing ?? candidate;
    if (!existing) store.add(key, "local");
    await finished(transaction);
  }

  const encode = new TextEncoder();
  const decode = new TextDecoder();

  async function put(table, id, value) {
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const data = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, encode.encode(JSON.stringify(value)));
    const transaction = database.transaction(table, "readwrite");
    const done = finished(transaction);
    transaction.objectStore(table).put({ iv, data }, id);
    await done;
  }

  async function values(table) {
    const rows = await requestValue(database.transaction(table).objectStore(table).getAll());
    return Promise.all(rows.map(async ({ iv, data }) => {
      const clear = await crypto.subtle.decrypt({ name: "AES-GCM", iv }, key, data);
      return JSON.parse(decode.decode(clear));
    }));
  }

  return {
    names: () => values("names"),
    attempts: () => values("attempts"),
    rename: (id, name) => put("names", id, { id, name }),
    add: attempt => put("attempts", attempt.id, attempt),
    queue: (attempt, record, scope) => put("outbox", attempt.id, { attempt, record, scope }),
    pending: async scope => (await values("outbox")).filter(item => item.scope === scope),
    async sent(id) {
      const transaction = database.transaction("outbox", "readwrite");
      const done = finished(transaction);
      transaction.objectStore("outbox").delete(id);
      await done;
    },
  };
}
