const utf8 = new TextEncoder();
const text = new TextDecoder();
const hex = /^[a-f0-9]{64}$/u;
const tokenKey = "mccup-team-session";
const hexBytes = value => Uint8Array.from(value.match(/../gu), x => parseInt(x, 16));
const toHex = bytes => Array.from(new Uint8Array(bytes), x => x.toString(16).padStart(2, "0")).join("");
const pack = bytes => btoa(String.fromCharCode(...new Uint8Array(bytes))).replaceAll("+", "-").replaceAll("/", "_").replace(/=+$/u, "");
const unpack = value => Uint8Array.from(atob(value.replaceAll("-", "+").replaceAll("_", "/")), char => char.charCodeAt(0));

export async function derive(master, purpose) {
  const key = await crypto.subtle.importKey("raw", hexBytes(master), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  return toHex(await crypto.subtle.sign("HMAC", key, utf8.encode("mccup/v1/" + purpose)));
}

async function recordKey(value) {
  return crypto.subtle.importKey("raw", hexBytes(value), "AES-GCM", false, ["encrypt", "decrypt"]);
}

async function request(token, path, options = {}) {
  const response = await fetch(path, {
    ...options, cache: "no-store",
    headers: { "Authorization": "Bearer " + token, ...options.headers },
  });
  if (!response.ok) throw new Error(response.status === 403 ? "invite" : "sync");
  return response.json();
}

export async function connectTeam() {
  const fragment = location.hash.slice(1);
  const fromLink = fragment.startsWith("owner.") || fragment.startsWith("member.");
  if (fromLink) history.replaceState(null, "", location.pathname + location.search);
  let remembered = null;
  try { remembered = localStorage.getItem(tokenKey); } catch { /* session storage is enough */ }
  const raw = fromLink ? fragment : sessionStorage.getItem(tokenKey) ?? remembered;
  if (!raw) return null;
  const [kind, first, second] = raw.split(".");
  if (!hex.test(first) || (kind === "member" && !hex.test(second)) || !["owner", "member"].includes(kind)) throw new Error("invite");
  const token = kind === "owner" ? await derive(first, "owner-auth") : first;
  const info = await request(token, "./api/team");
  if (info.role !== kind) throw new Error("invite");
  const historyEpoch = info.historyEpoch ?? null;

  const keys = new Map();
  const keyFor = async slot => {
    if (!keys.has(slot) && kind === "owner") keys.set(slot, recordKey(await derive(first, "record-" + slot)));
    const key = keys.get(slot);
    if (!key) throw new Error("invite");
    return key;
  };
  if (kind === "member") keys.set(info.slot, recordKey(second));
  async function open(slot, envelope, associated) {
    const data = await crypto.subtle.decrypt(
      { name: "AES-GCM", iv: unpack(envelope.iv), additionalData: utf8.encode(associated) },
      await keyFor(slot), unpack(envelope.data));
    return JSON.parse(text.decode(data));
  }
  const profiles = await Promise.all(info.profiles.map(async item => ({
    id: item.slot, ...await open(item.slot, item, "name:" + item.slot),
  })));
  const bankKey = await recordKey(profiles[0].bankKey);
  const roster = profiles.map(({ id, name }) => ({ id, name }));
  if (kind === "member" && info.timeline) {
    const peers = await open(info.slot, info.timeline, "timeline/v1:" + info.slot);
    for (const { id, name, key } of peers) {
      if (!Number.isSafeInteger(id) || id < 0 || keys.has(id) || !hex.test(key) ||
          typeof name !== "string" || !name.trim()) throw new Error("invite");
      keys.set(id, recordKey(key));
      roster.push({ id, name });
    }
  }
  roster.sort((a, b) => a.id - b.id);
  sessionStorage.setItem(tokenKey, raw);
  if (kind === "member" && (fromLink || !remembered)) {
    try { localStorage.setItem(tokenKey, raw); } catch { /* session storage is enough */ }
  }

  return {
    role: info.role,
    slot: info.slot,
    historyEpoch,
    profiles: roster,
    async questions() {
      const { iv, data } = await request(token, "./api/bank");
      const unlocked = await crypto.subtle.decrypt(
        { name: "AES-GCM", iv: unpack(iv), additionalData: utf8.encode("team-questions/v1") },
        bankKey, unpack(data));
      return JSON.parse(text.decode(unlocked));
    },
    async questionAudio(id) {
      const response = await fetch("./api/question-audio?id=" + encodeURIComponent(id), {
        headers: { "Authorization": "Bearer " + token }, cache: "no-store",
      });
      if (!response.ok) throw new Error("audio");
      const bytes = new Uint8Array(await response.arrayBuffer());
      return crypto.subtle.decrypt({
        name: "AES-GCM", iv: bytes.subarray(0, 12),
        additionalData: utf8.encode("question-audio/v1:" + id),
      }, bankKey, bytes.subarray(12));
    },
    queueKey: token,
    async makeRecord(attempt) {
      if (kind === "member" && attempt.member !== info.slot) throw new Error("invite");
      const iv = crypto.getRandomValues(new Uint8Array(12));
      const data = await crypto.subtle.encrypt(
        { name: "AES-GCM", iv, additionalData: utf8.encode("attempt:" + attempt.member + ":" + attempt.id) },
        await keyFor(attempt.member), utf8.encode(JSON.stringify(attempt)));
      return { slot: attempt.member, envelope: { id: attempt.id, iv: pack(iv), data: pack(data) } };
    },
    async send({ slot, envelope }) {
      const headers = { "Content-Type": "application/json" };
      if (historyEpoch) headers["X-Practice-History-Epoch"] = historyEpoch;
      await request(token, "./api/records?slot=" + slot, {
        method: "POST", headers, body: JSON.stringify(envelope),
      });
    },
    async attempts(slot) {
      let next = null;
      const records = [];
      do {
        const query = "./api/records?slot=" + slot + (next ? "&cursor=" + encodeURIComponent(next) : "");
        const page = await request(token, query);
        const unlocked = await Promise.all(page.records.map(row => open(slot, row, "attempt:" + slot + ":" + row.id)));
        records.push(...unlocked.filter((record, index) => record.member === slot && record.id === page.records[index].id));
        next = page.next;
      } while (next);
      return records;
    },
  };
}

export function leaveTeam() {
  sessionStorage.removeItem(tokenKey);
  try { localStorage.removeItem(tokenKey); } catch { /* no stored login */ }
}
