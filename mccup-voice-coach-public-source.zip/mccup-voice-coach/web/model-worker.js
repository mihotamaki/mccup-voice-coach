import { pipeline, env } from "./transformers.js";

env.allowLocalModels = false;
env.useBrowserCache = true;
env.backends.onnx.wasm.numThreads = 1;
env.backends.onnx.wasm.wasmPaths = "https://cdn.jsdelivr.net/npm/@huggingface/transformers@3.8.1/dist/";

const engines = {};
function engine(task, model) {
  if (!engines[task]) {
    engines[task] = pipeline(task, model, {
      device: "wasm", dtype: "q8",
      progress_callback: event => {
        if (event.status === "progress") {
          postMessage({ status: "loading", percent: Math.min(100, Math.floor(event.progress)) });
        }
      },
    }).catch(error => {
      delete engines[task];
      throw error;
    });
  }
  return engines[task];
}

self.onmessage = async ({ data }) => {
  try {
    if (data.kind === "transcribe") {
      const whisper = await engine("automatic-speech-recognition", "Xenova/whisper-tiny");
      const result = await whisper(data.audio, { language: "japanese", task: "transcribe",
        chunk_length_s: 25, stride_length_s: 4, return_timestamps: false });
      postMessage({ id: data.id, result: result.text.trim() });
    } else if (data.kind === "embedding") {
      const e5 = await engine("feature-extraction", "Xenova/multilingual-e5-small");
      const result = await e5(data.text, { pooling: "mean", normalize: true });
      postMessage({ id: data.id, result: result.tolist() });
    }
  } catch (error) {
    const issue = location.hostname === "127.0.0.1" ? String(error.message).slice(0, 240) : undefined;
    postMessage({ id: data.id, failed: true, issue });
  }
};
