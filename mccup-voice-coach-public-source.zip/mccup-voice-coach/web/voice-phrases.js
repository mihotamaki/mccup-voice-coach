import { criteria, spokenTips } from "./rubric.js";

export const phrases = {
  beginning: "練習の結果です。",
  total: "60点満点の合計",
  skipped: "は、まだ点数がついていません。",
  praise: "自分のことばで答えられましたね。",
  ...Object.fromEntries(criteria.map((label, index) => ["criterion-" + index, label])),
  ...Object.fromEntries(Array.from({ length: 61 }, (_, number) => ["score-" + number, "は、" + number + "点です。"])),
  ...Object.fromEntries(spokenTips.map((tip, index) => ["tip-" + index, tip])),
};
