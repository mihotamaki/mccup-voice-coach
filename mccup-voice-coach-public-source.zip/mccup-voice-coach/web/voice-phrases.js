import { criteria, spokenReasons, spokenTips } from "./rubric.js";

const stars = ["ゼロ", "ひとつ", "ふたつ", "みっつ", "よっつ", "いつつ"];

export const phrases = {
  beginning: "練習の結果です。",
  "question-score": "この質問の練習点",
  skipped: "は、まだ評価がついていません。",
  "all-skipped": "評価できる回答がありませんでした。",
  ...Object.fromEntries(criteria.map((label, index) => ["criterion-" + index, label])),
  ...Object.fromEntries(stars.map((label, index) => ["stars-" + index, "は、星いつつのうち、" + label + "です。"])),
  ...Object.fromEntries(spokenReasons.map((reason, index) => ["reason-" + index, reason])),
  ...Object.fromEntries(Array.from({ length: 101 }, (_, number) => ["score-" + number, "は、" + number + "点です。"])),
  ...Object.fromEntries(spokenTips.map((tip, index) => ["tip-" + index, tip])),
};
