#!/bin/zsh
set -eu
umask 077
support="$HOME/Library/Application Support/OwaseVoiceCoach"
if [[ -x /opt/homebrew/bin/python3 ]]; then
  python=/opt/homebrew/bin/python3
elif [[ -x /usr/local/bin/python3 ]]; then
  python=/usr/local/bin/python3
else
  python=$(command -v python3)
fi
"$python" -c 'import sys, platform; assert sys.version_info >= (3, 10) and platform.machine() == "arm64", "Python 3.10以降のApple Silicon版が必要です"'
mkdir -p "$support"
"$python" -m venv "$support/runtime"
"$support/runtime/bin/python3" -m pip install 'mlx-whisper==0.4.3' scipy
HF_HUB_DISABLE_TELEMETRY=1 "$support/runtime/bin/python3" - <<'PY'
from huggingface_hub import snapshot_download
snapshot_download("mlx-community/whisper-small-mlx", allow_patterns=["config.json", "weights.npz"])
PY
echo "Whisperの準備ができました。"
