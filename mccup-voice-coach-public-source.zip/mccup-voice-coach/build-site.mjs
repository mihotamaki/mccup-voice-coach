import { copyFile, mkdir, readFile, readdir, writeFile } from "node:fs/promises";
const assets = {};
for (const file of await readdir("web")) {
  if (!/^[a-z-]+\.(?:html|css|js|json)$/u.test(file)) continue;
  assets[file] = await readFile("web/" + file, "utf8");
}
await mkdir("dist/server", { recursive: true });
await mkdir("dist/.openai", { recursive: true });
await copyFile(".openai/hosting.json", "dist/.openai/hosting.json");
const worker = await readFile("worker.js", "utf8");
await writeFile("dist/server/index.js", "const ASSETS = " + JSON.stringify(assets) + ";\n" + worker);
