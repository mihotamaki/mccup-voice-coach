import { copyFile, mkdir, readFile, readdir, writeFile } from "node:fs/promises";
const assets = {};
const binaryAssets = {};
for (const file of await readdir("web")) {
  if (/^(?:[a-z-]+\.png|voice-[a-z0-9-]+\.(?:mp3|bin))$/u.test(file)) {
    binaryAssets[file] = (await readFile("web/" + file)).toString("base64");
  } else if (/^[a-z-]+\.(?:html|css|js|json|svg|webmanifest)$/u.test(file)) {
    assets[file] = await readFile("web/" + file, "utf8");
  }
}
await mkdir("dist/server", { recursive: true });
await mkdir("dist/.openai", { recursive: true });
await copyFile(".openai/hosting.json", "dist/.openai/hosting.json");
const worker = await readFile("worker.js", "utf8");
await writeFile("dist/server/index.js", "const ASSETS = " + JSON.stringify(assets) + ";\nconst BINARY_ASSETS = " + JSON.stringify(binaryAssets) + ";\n" + worker);
