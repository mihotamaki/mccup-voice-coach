import { readFileSync, writeFileSync } from "node:fs";
import { createCipheriv, createDecipheriv, createHmac, randomBytes } from "node:crypto";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";
import { phrases } from "./web/voice-phrases.js";

const [python, linksFile, configFile] = process.argv.slice(2);
if (!python || Boolean(linksFile) !== Boolean(configFile)) {
  throw new Error("Usage: node generate-voice.mjs PYTHON [LOCAL_LINKS LOCAL_HOST_CONFIG]");
}
const publicQuestions = JSON.parse(readFileSync("web/questions.json", "utf8"));
const jobs = [
  ...publicQuestions.map(({ id, text }) => ["public-" + id, text]),
  ...Object.entries(phrases),
];
let bankKey;
if (linksFile) {
  const links = readFileSync(linksFile, "utf8");
  const master = Buffer.from(links.match(/#owner\.([a-f0-9]{64})/u)[1], "hex");
  const config = JSON.parse(readFileSync(configFile, "utf8"));
  const { slot, iv, data } = config.profiles[0];
  const key = createHmac("sha256", master).update("mccup/v1/record-" + slot).digest();
  const bytes = Buffer.from(data, "base64url");
  const decipher = createDecipheriv("aes-256-gcm", key, Buffer.from(iv, "base64url"));
  decipher.setAAD(Buffer.from("name:" + slot));
  decipher.setAuthTag(bytes.subarray(-16));
  bankKey = Buffer.from(JSON.parse(Buffer.concat([decipher.update(bytes.subarray(0, -16)), decipher.final()])).bankKey, "hex");
  const teamQuestions = JSON.parse(readFileSync("questions.json", "utf8"));
  jobs.push(...teamQuestions.map(({ id, text }) => ["team-" + id, text]));
}

const output = spawnSync(python, [fileURLToPath(new URL("./render-voice.py", import.meta.url))],
  { input: JSON.stringify(jobs), encoding: "utf8", maxBuffer: 24 * 1024 * 1024, stdio: ["pipe", "pipe", "inherit"] });
if (output.status !== 0) throw new Error("音声を生成できませんでした。");
const clips = JSON.parse(output.stdout);
for (const [id, encoded] of Object.entries(clips)) {
  const mp3 = Buffer.from(encoded, "base64");
  if (id.startsWith("team-")) {
    const iv = randomBytes(12);
    const cipher = createCipheriv("aes-256-gcm", bankKey, iv);
    cipher.setAAD(Buffer.from("question-audio/v1:" + id.slice(5)));
    const locked = Buffer.concat([iv, cipher.update(mp3), cipher.final(), cipher.getAuthTag()]);
    writeFileSync("web/voice-" + id + ".bin", locked);
  } else {
    writeFileSync("web/voice-" + id + ".mp3", mp3);
  }
}
console.log(Object.keys(clips).length + " clips generated");
