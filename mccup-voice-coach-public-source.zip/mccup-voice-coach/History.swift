import CryptoKit
import Foundation
import Security

struct Attempt: Codable, Identifiable, Equatable {
    let id: UUID
    let session: UUID
    let at: Date
    let question: String
    let answer: String
    let criterion: String
    let score: Int
    let good: String
    let evidence: String
    let next: String
}

struct Member: Codable, Identifiable {
    let id: Int
    var name: String
    var attempts: [Attempt] = []
}

@MainActor
final class History: ObservableObject {
    @Published private(set) var members: [Member]
    @Published private(set) var error: String?

    private let directory: URL
    private var database: URL { directory.appendingPathComponent("history.sealed") }
    private let key: () throws -> SymmetricKey
    private var readable = true

    convenience init() {
        let root = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        self.init(directory: root.appendingPathComponent("OwaseVoiceCoach", isDirectory: true), key: Self.keychainKey)
    }

    init(directory: URL, key: @escaping () throws -> SymmetricKey) {
        self.directory = directory
        self.key = key
        let roster = directory.appendingPathComponent("roster.json")
        let names = (try? JSONDecoder().decode([String].self, from: Data(contentsOf: roster))) ?? []
        members = (0..<5).map { i in
            Member(id: i, name: names.indices.contains(i) ? names[i] : "メンバー \(i + 1)")
        }

        if FileManager.default.fileExists(atPath: database.path) {
            do {
                let box = try AES.GCM.SealedBox(combined: Data(contentsOf: database))
                let saved = try JSONDecoder().decode([Member].self, from: AES.GCM.open(box, using: key()))
                guard saved.map(\.id) == Array(0..<5) else { throw HistoryError.invalid }
                members = saved
            } catch {
                readable = false
                self.error = "記録を開けません。キーチェーンが使える状態でアプリを開き直してください。"
            }
        }
    }

    func rename(_ id: Int, to value: String) throws {
        let name = String(value.trimmingCharacters(in: .whitespacesAndNewlines).prefix(18))
        guard !name.isEmpty else { throw HistoryError.invalid }
        var updated = members
        updated[id].name = name
        try save(updated)
    }

    func add(_ attempt: Attempt, member: Int) throws {
        var updated = members
        if updated[member].attempts.contains(where: { $0.id == attempt.id }) { return }
        updated[member].attempts.append(attempt)
        try save(updated)
    }

    private func save(_ updated: [Member]) throws {
        guard readable else { throw HistoryError.invalid }
        do {
            let files = FileManager.default
            try files.createDirectory(at: directory, withIntermediateDirectories: true,
                                      attributes: [.posixPermissions: 0o700])
            let data = try JSONEncoder().encode(updated)
            guard let sealed = try AES.GCM.seal(data, using: key()).combined else { throw HistoryError.invalid }
            try sealed.write(to: database, options: .atomic)
            members = updated
            error = nil
        } catch {
            self.error = "記録を保存できませんでした。キーチェーンの利用を許可し、もう一度お試しください。"
            throw error
        }
    }

    private static func keychainKey() throws -> SymmetricKey {
        let attributes: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: "local.owase.minecraftcup.voicecoach.history",
            kSecAttrAccount as String: "record-key",
        ]
        var request = attributes
        request[kSecReturnData as String] = true
        request[kSecMatchLimit as String] = kSecMatchLimitOne
        var value: CFTypeRef?
        let status = SecItemCopyMatching(request as CFDictionary, &value)
        if status == errSecSuccess, let data = value as? Data, data.count == 32 {
            return SymmetricKey(data: data)
        }
        guard status == errSecItemNotFound else { throw HistoryError.keychain(status) }
        let key = SymmetricKey(size: .bits256)
        var newItem = attributes
        newItem[kSecValueData as String] = key.withUnsafeBytes { Data($0) }
        let added = SecItemAdd(newItem as CFDictionary, nil)
        if added == errSecDuplicateItem { return try keychainKey() }
        guard added == errSecSuccess else { throw HistoryError.keychain(added) }
        return key
    }

    private enum HistoryError: Error {
        case invalid
        case keychain(OSStatus)
    }
}
